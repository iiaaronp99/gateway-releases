@echo off
cd /d "%~dp0"
if not exist .env (
  echo There is no .env file in this folder yet.
  echo Copy .env.example, rename the copy to .env, then open it in Notepad.
  echo HOW-TO-START.txt has the clicks.
  pause
  exit /b 1
)
findstr /C:"paste-your-" /C:"sk-replace-me" .env >nul
if not errorlevel 1 (
  echo .env still has placeholder text.
  echo Open .env in Notepad and paste your own keys. Do not leave sk-replace-me.
  pause
  exit /b 1
)
echo Starting Gateway on http://localhost:4000
echo The first start can take a few minutes.
docker compose up -d --build
if errorlevel 1 (
  echo.
  echo Docker did not start the gateway.
  echo Open Docker Desktop and wait until it says it is running, then double-click this file again.
)
echo.
pause
