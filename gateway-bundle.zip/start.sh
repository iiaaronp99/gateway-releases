#!/usr/bin/env bash
# Start the local gateway. Works on macOS and Linux (Git Bash on Windows too).
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed, or it is not on your PATH."
  echo "Install Docker Desktop, open it, wait until it says it is running, then try again."
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  echo "Docker is installed, but the engine is not running."
  echo "Open Docker Desktop and wait until it says it is running, then try again."
  exit 1
fi

if [[ ! -f .env ]]; then
  echo "Missing .env in this folder."
  echo "Copy the example, then paste your keys:"
  echo "  cp .env.example .env"
  exit 1
fi

if grep -q "paste-your-" .env || grep -q "sk-replace-me" .env; then
  echo "Your .env still has placeholder text (paste-your-... or sk-replace-me)."
  echo "Open .env, paste your Gemini and OpenRouter keys, and set LITELLM_MASTER_KEY."
  exit 1
fi

echo "Starting the gateway on http://localhost:4000"
echo "The first start downloads LiteLLM and builds the small router. That can take a few minutes."
echo "Leave this window open. Press Ctrl+C to stop."
echo "To run in the background instead, use: docker compose up -d --build"
exec docker compose up
