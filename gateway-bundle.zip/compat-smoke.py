"""Check the OpenAI-compatible routes on a gateway that is already running.

From the gateway folder (or the unzipped friend bundle):

  python3 compat-smoke.py

Windows, if Python is installed:

  py -3 compat-smoke.py

It reads LITELLM_MASTER_KEY from the environment or from .env in this folder.
It does not print the key. A missing Ollama embedding model is a warning, not
a failed chat check. Friends can skip this and use the app's own test.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


BASE = os.environ.get("GATEWAY_URL", "http://localhost:4000").rstrip("/")


def load_key() -> str:
    key = os.environ.get("LITELLM_MASTER_KEY", "").strip()
    if key:
        return key
    env = Path(".env")
    if not env.is_file():
        return ""
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if name.strip() == "LITELLM_MASTER_KEY":
            return value.strip()
    return ""


def request(method: str, path: str, key: str, body: dict | None = None, stream: bool = False) -> tuple[int, str]:
    data = None if body is None else json.dumps(body).encode("utf-8")
    headers = {"Authorization": f"Bearer {key}"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            raw = response.read(8000 if stream else 200000)
            return response.status, raw.decode("utf-8", errors="replace")
    except urllib.error.HTTPError as error:
        raw = error.read(4000).decode("utf-8", errors="replace")
        return error.code, raw
    except urllib.error.URLError as error:
        return 0, str(error.reason)


def main() -> int:
    key = load_key()
    if not key or key == "sk-replace-me":
        print("Set LITELLM_MASTER_KEY in .env first. The placeholder does not work.")
        return 1
    failed = False

    status, text = request("GET", "/v1/models", key)
    names: list[str] = []
    try:
        names = [row.get("id", "") for row in json.loads(text).get("data", [])]
    except json.JSONDecodeError:
        names = []
    models_ok = status == 200 and "auto" in names
    print(f"GET /v1/models: {'PASS' if models_ok else 'FAIL'} ({status})")
    failed = failed or not models_ok

    status, text = request(
        "POST",
        "/v1/chat/completions",
        key,
        {"model": "auto", "stream": True, "messages": [{"role": "user", "content": "Reply with the single word: pong"}]},
        stream=True,
    )
    chat_ok = status == 200 and "data:" in text
    print(f"POST /v1/chat/completions stream: {'PASS' if chat_ok else 'FAIL'} ({status})")
    failed = failed or not chat_ok

    status, text = request(
        "POST",
        "/v1/chat/completions",
        key,
        {
            "model": "t1",
            "messages": [{"role": "user", "content": "ping"}],
            "tools": [{"type": "function", "function": {"name": "ping", "parameters": {"type": "object", "properties": {}}}}],
        },
    )
    tools_ok = status != 404 and status != 0
    print(f"POST tools: {'PASS' if status == 200 else 'WARN' if tools_ok else 'FAIL'} ({status})")
    failed = failed or not tools_ok

    status, text = request("POST", "/v1/embeddings", key, {"model": "embed", "input": "hello"})
    if status == 404 or status == 0:
        print(f"POST /v1/embeddings: FAIL ({status})")
        failed = True
    elif status == 200 and "embedding" in text:
        print("POST /v1/embeddings: PASS (200)")
    else:
        print(f"POST /v1/embeddings: WARN ({status}). Chat can still work. For embeddings run: ollama pull nomic-embed-text")

    status, text = request(
        "POST",
        "/v1/messages",
        key,
        {"model": "smart", "max_tokens": 16, "messages": [{"role": "user", "content": "Reply with the single word: pong"}]},
    )
    messages_ok = status != 404 and status != 0
    label = "PASS" if status == 200 else "WARN" if messages_ok else "FAIL"
    print(f"POST /v1/messages: {label} ({status})")
    failed = failed or not messages_ok

    if failed:
        print("One or more routes failed. Snippets above are statuses only. The key was not printed.")
        return 1
    print("Routes answered. Provider warnings still mean that route exists.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
