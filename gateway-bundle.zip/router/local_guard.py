"""Decide whether a caller is on this computer.

The app-register route is open to local programs so Odyssey can connect
without the Gateway password. A request that did not come from this
machine is refused. X-Forwarded-For is never treated as proof that the
caller is local.
"""

from __future__ import annotations

LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost"}


def is_loopback_host(host: str | None) -> bool:
    if not host:
        return False
    text = host.strip().lower()
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1]
    if "%" in text:
        text = text.split("%", 1)[0]
    return text in LOOPBACK_HOSTS


def host_header_is_local(value: str | None) -> bool:
    """Allow a missing Host and the usual localhost names. Refuse a public name."""
    if value is None:
        return True
    text = value.strip().lower()
    if not text:
        return True
    host = text.split(",")[0].strip()
    if host.startswith("["):
        end = host.find("]")
        name = host[1:end] if end != -1 else host
    else:
        name = host.rsplit(":", 1)[0] if host.count(":") == 1 else host
    return is_loopback_host(name)


def origin_is_local(origin: str | None) -> bool:
    """A browser on another site must not register an app. No Origin is fine."""
    if origin is None:
        return True
    text = origin.strip().lower()
    if text in {"", "null"}:
        return True
    if text.startswith("http://127.0.0.1") or text.startswith("http://localhost") or text.startswith("http://[::1]"):
        return True
    if text.startswith("tauri://") or text.startswith("http://tauri.localhost") or text.startswith("https://tauri.localhost"):
        return True
    return False


def forwarded_for_is_remote(value: str | None) -> bool:
    """True when a proxy says the original caller was not this computer."""
    if value is None:
        return False
    first = value.split(",")[0].strip()
    if not first:
        return False
    return not is_loopback_host(first)


def registration_block(
    client_host: str | None,
    host_header: str | None,
    origin: str | None,
    forwarded_for: str | None,
) -> str | None:
    """An error sentence when this caller must not register or list apps."""
    if forwarded_for_is_remote(forwarded_for):
        return "This action only works on this computer."
    if not is_loopback_host(client_host):
        return "This action only works on this computer."
    if not host_header_is_local(host_header):
        return "This action only works on this computer."
    if not origin_is_local(origin):
        return "This action only works on this computer."
    return None
