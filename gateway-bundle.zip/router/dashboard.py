"""One page Aaron can open in a browser. No extra install, no internet."""

from __future__ import annotations

from html import escape


TASK_LABELS = {
    "quick_chat": "Quick chat",
    "coding": "Coding",
    "code_review": "Code review",
    "debug": "Debug",
    "summarize": "Summarize",
    "extract": "Extract",
    "rewrite": "Rewrite",
    "translate": "Translate",
    "hard_reasoning": "Hard reasoning",
    "tool_agent": "Tool or agent",
    "planning": "Planning",
    "creative": "Creative",
    "classify": "Classify",
    "long_context": "Long input",
    "data_qa": "Questions about data",
    "other": "Other",
}


def _money(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"${value:.4f}"


def _ms(value: int | None) -> str:
    if value is None:
        return "n/a"
    if value >= 1000:
        return f"{value / 1000:.1f} s"
    return f"{value} ms"


def _outcome(status: object) -> str:
    if isinstance(status, bool) or not isinstance(status, (int, str)):
        return "Failed"
    try:
        code = int(status)
    except ValueError:
        return "Failed"
    if code > 0 and code < 400:
        return "Succeeded"
    return "Failed"


def _task(name: str) -> str:
    label = TASK_LABELS.get(name)
    if label is None:
        return name or "(not recorded)"
    return f"{label}"


def _bars(rows: list[dict], field: str, fmt) -> str:
    if not rows:
        return "<p>Nothing in this group yet.</p>"
    amounts = [row[field] or 0 for row in rows]
    widest = max(amounts) or 1
    lines = []
    for row, amount in zip(rows, amounts):
        width = 0 if not amount else max(4, round(100 * amount / widest))
        lines.append(
            "<tr>"
            f"<td>{escape(str(row['name']))}</td>"
            f"<td class='num'>{escape(fmt(amount))}</td>"
            f"<td><div class='track'><div class='bar' style='width:{width}%'></div></div></td>"
            f"<td class='num'>{row['requests']} call{'s' if row['requests'] != 1 else ''}</td>"
            "</tr>"
        )
    return "<table class='bars'>" + "".join(lines) + "</table>"


def render(report: dict) -> str:
    paragraph = escape(report["paragraph"])
    cost = escape(_money(report["cost"]))
    calls = str(report["requests"])
    wait = escape(_ms(report["avg_latency_ms"]))
    median = escape(_ms(report["median_latency_ms"]))
    cost_rows = _bars(report["by_model"], "cost", lambda amount: _money(float(amount)))
    wait_rows = _bars(
        [row for row in report["by_model"] if row["avg_latency_ms"] is not None],
        "avg_latency_ms",
        lambda amount: _ms(int(amount)),
    )
    task_lines = []
    for row in report["by_task"]:
        task_lines.append(
            "<tr>"
            f"<td>{escape(_task(row['name']))}</td>"
            f"<td class='num'>{row['requests']}</td>"
            f"<td class='num'>{escape(_money(row['cost']))}</td>"
            f"<td class='num'>{escape(_ms(row['avg_latency_ms']))}</td>"
            f"<td class='num'>{row['tokens']}</td>"
            f"<td class='num'>{row['fallbacks']}</td>"
            "</tr>"
        )
    tasks = (
        "<table><thead><tr><th>Kind of chat</th><th>Calls</th><th>Cost</th><th>Average wait</th><th>Tokens</th><th>Step-downs</th></tr></thead><tbody>"
        + "".join(task_lines)
        + "</tbody></table>"
        if task_lines
        else "<p>No calls in this week yet.</p>"
    )
    recent_lines = []
    for row in report["recent"]:
        recent_lines.append(
            "<tr>"
            f"<td>{escape(row['time'])}</td>"
            f"<td>{escape(str(row.get('app') or 'Gateway'))}</td>"
            f"<td>{escape(_outcome(row.get('status')))}</td>"
            f"<td>{escape(row['requested_model'])}</td>"
            f"<td>{escape(_task(row['task_class']))}</td>"
            f"<td>{escape(row['served_model'] or row['chosen_tier'])}</td>"
            f"<td class='num'>{escape(_ms(row['latency_ms']))}</td>"
            f"<td class='num'>{escape(_money(row['cost']))}</td>"
            f"<td class='num'>{row['fallbacks']}</td>"
            "</tr>"
        )
    recent = (
        "<table><thead><tr><th>When (UTC)</th><th>App</th><th>Status</th><th>You asked for</th><th>Kind</th><th>Answered by</th><th>Wait</th><th>Cost</th><th>Step-downs</th></tr></thead><tbody>"
        + "".join(recent_lines)
        + "</tbody></table>"
        if recent_lines
        else ""
    )
    keys = ""
    if report["keys"] > 1:
        keys = f"<p>{report['keys']} different keys sent calls this week. The numbers above add them together. Learning stays separate per key.</p>"
    marks = report["marks"]
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gateway costs</title>
<style>
  body {{ margin: 0; background: #f3efe6; color: #1c1915; font: 18px/1.45 "Segoe UI", system-ui, sans-serif; }}
  main {{ max-width: 920px; margin: 0 auto; padding: 28px 20px 64px; }}
  h1 {{ font-size: 2rem; margin: 0 0 6px; }}
  h2 {{ font-size: 1.25rem; margin: 28px 0 8px; }}
  p.lead {{ font-size: 1.15rem; background: #fff; border: 1px solid #e2d8c8; border-radius: 12px; padding: 16px 18px; }}
  .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-top: 16px; }}
  .card {{ background: #fff; border: 1px solid #e2d8c8; border-radius: 12px; padding: 14px 16px; }}
  .card span {{ display: block; color: #5c564c; font-size: 0.9rem; }}
  .card strong {{ font-size: 1.8rem; }}
  table {{ width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; }}
  th, td {{ text-align: left; padding: 8px 10px; border-bottom: 1px solid #efe7da; vertical-align: middle; }}
  th {{ color: #5c564c; font-weight: 600; font-size: 0.85rem; }}
  td.num, th.num {{ text-align: right; white-space: nowrap; }}
  .track {{ background: #efe7da; border-radius: 999px; height: 14px; min-width: 80px; }}
  .bar {{ background: #0f6e6e; height: 14px; border-radius: 999px; }}
  .muted {{ color: #5c564c; }}
  a {{ color: #0f6e6e; }}
</style>
</head>
<body>
<main>
  <h1>Gateway costs</h1>
  <p class="muted">This computer only. {escape(report['since'])} to {escape(report['until'])}.</p>
  <p class="lead">{paragraph}</p>
  <div class="cards">
    <div class="card"><span>Cost this week</span><strong>{cost}</strong></div>
    <div class="card"><span>Calls</span><strong>{calls}</strong></div>
    <div class="card"><span>Average wait</span><strong>{wait}</strong></div>
    <div class="card"><span>Typical wait</span><strong>{median}</strong></div>
  </div>
  <p class="muted">Typical wait is the middle call, so one slow outlier does not move it as much as the average.</p>
  {keys}
  <h2>Cost by model</h2>
  <p class="muted">Free Gemini, OpenRouter :free, and Ollama stay at $0.00. A paid model would show dollars here.</p>
  {cost_rows}
  <h2>Wait by model</h2>
  {wait_rows}
  <h2>By kind of chat</h2>
  {tasks}
  <h2>Good and bad marks</h2>
  <p>{marks['good']} good, {marks['bad']} bad. Mark the last reply with <code>gw.ps1 good</code> or <code>gw.ps1 bad</code>.</p>
  <h2>Moved up a tier</h2>
  <p>{report['cascades']} auto call{'s' if report['cascades'] != 1 else ''} tried a cheaper model first, then one stronger model. Streaming calls only do this before the first word is sent.</p>
  <h2>Recent calls</h2>
  {recent or '<p>No calls yet.</p>'}
</main>
</body>
</html>
"""
