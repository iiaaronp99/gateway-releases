"""Local memory for calls, marks, and the per-user scores.

The file is SQLite. Docker keeps it in the gateway-data volume.
`docker compose down` keeps it. `docker compose down -v` deletes it.

The API key is not stored. A short hash of the key is the user id, so two
keys learn separately even when both are used on this computer. When a
client also sends a user field, that person gets their own scores under
the same key.
"""

from __future__ import annotations

import hashlib
import sqlite3
import threading
import time
from pathlib import Path

from classify import class_to_type
from learn import learning_tier

# Raw learning rows older than this are deleted. Win/loss counts stay.
RETENTION_SECONDS = 90 * 24 * 60 * 60

SIGNAL_WINS = {"good", "copy"}
SIGNAL_LOSSES = {"bad", "regenerate", "cancel", "switch", "error", "timeout"}
SIGNAL_KINDS = SIGNAL_WINS | SIGNAL_LOSSES | {"latency"}
# A learning body that carries chat text is refused. Counts stay metadata.
BLOCKED_LEARNING_KEYS = {
    "prompt",
    "prompts",
    "messages",
    "content",
    "text",
    "output",
    "completion",
    "response",
    "reply",
    "input",
}


def learning_body_error(payload: dict) -> str | None:
    """Reject prompt or reply text. Learning stores model, task, and outcome only."""
    blocked = BLOCKED_LEARNING_KEYS.intersection(payload)
    if blocked:
        return "Learning stores model, task, and outcome only. Prompt and reply text are not accepted."
    for value in payload.values():
        if isinstance(value, (dict, list)):
            return "Learning stores model, task, and outcome only. Prompt and reply text are not accepted."
        if isinstance(value, str) and len(value) > 200:
            return "That learning note is too long. Send the model id and the kind of signal only."
    return None


def _median(values: list[int]) -> int | None:
    if not values:
        return None
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2 == 1:
        return int(ordered[mid])
    return int((ordered[mid - 1] + ordered[mid]) / 2)


def _buckets(rows: list[dict], key: str) -> list[dict]:
    groups: dict[str, dict] = {}
    for row in rows:
        name = row.get(key) or "(not recorded)"
        group = groups.get(name)
        if group is None:
            group = {
                "name": name,
                "requests": 0,
                "cost": 0.0,
                "latencies": [],
                "tokens": 0,
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "fallbacks": 0,
            }
            groups[name] = group
        group["requests"] += 1
        if row["cost"] is not None:
            group["cost"] += float(row["cost"])
        if row["latency_ms"] is not None:
            group["latencies"].append(int(row["latency_ms"]))
        if row["total_tokens"] is not None:
            group["tokens"] += int(row["total_tokens"])
        if row["prompt_tokens"] is not None:
            group["prompt_tokens"] += int(row["prompt_tokens"])
        if row["completion_tokens"] is not None:
            group["completion_tokens"] += int(row["completion_tokens"])
        group["fallbacks"] += int(row["fallbacks"] or 0)
    listed = []
    for group in groups.values():
        latencies = group.pop("latencies")
        group["avg_latency_ms"] = int(sum(latencies) / len(latencies)) if latencies else None
        group["cost"] = round(group["cost"], 6)
        listed.append(group)
    listed.sort(key=lambda item: (-item["requests"], item["name"]))
    return listed


def _paragraph(summary: dict) -> str:
    count = summary["requests"]
    if count == 0:
        return "No calls in the last 7 days. Send a chat, then refresh this page."
    if summary["cost"] == 0:
        money = (
            f"Last 7 days: {count} call{'s' if count != 1 else ''}, $0.00. "
            "The dollar cost is zero because these models are on the free tier or on this computer."
        )
    else:
        money = f"Last 7 days: {count} call{'s' if count != 1 else ''}, ${summary['cost']:.4f}."
    extra = []
    models = [row for row in summary["by_model"] if row["avg_latency_ms"] is not None]
    if models:
        quickest = min(models, key=lambda row: row["avg_latency_ms"])
        extra.append(f"The quickest model on average was {quickest['name']} ({quickest['avg_latency_ms']} ms).")
    tasks = summary["by_task"]
    if tasks:
        top = tasks[0]
        extra.append(f"The most common kind of chat was {top['name']} ({top['requests']} call{'s' if top['requests'] != 1 else ''}).")
    if summary["fallbacks"]:
        extra.append(f"{summary['fallbacks']} call{'s' if summary['fallbacks'] != 1 else ''} had to step down a tier.")
    if summary["cascades"]:
        extra.append(
            f"{summary['cascades']} auto call{'s' if summary['cascades'] != 1 else ''} "
            "moved up one tier after a weak or failed answer."
        )
    if summary["cost_missing"]:
        extra.append(f"{summary['cost_missing']} call{'s' if summary['cost_missing'] != 1 else ''} did not report a dollar cost.")
    marks = summary["marks"]
    if marks["good"] or marks["bad"]:
        extra.append(f"Marks this week: {marks['good']} good, {marks['bad']} bad.")
    return " ".join([money, *extra])


def key_hash(authorization: str | None) -> str:
    token = ""
    if authorization:
        parts = authorization.split(" ", 1)
        if len(parts) == 2 and parts[0].lower() == "bearer":
            token = parts[1].strip()
    if not token:
        return "anonymous"
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]


def user_id(authorization: str | None, end_user: str | None) -> str:
    base = key_hash(authorization)
    if end_user and end_user.strip():
        safe = end_user.strip().replace(":", "")[:80]
        return f"{base}:{safe}"
    return base


def recent_app_name(user_id: str | None, names: dict[str, str]) -> str:
    """Registered app name, or Gateway when the call used the gateway password.

    `names` maps the first 16 hex chars of an app key hash to the app name.
    The raw key, the prompt, and the reply are not part of this label.
    """
    prefix = (user_id or "").split(":", 1)[0]
    return names.get(prefix) or "Gateway"


class Store:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS requests (
                id TEXT PRIMARY KEY,
                ts REAL NOT NULL,
                user_id TEXT NOT NULL,
                requested_model TEXT,
                task_class TEXT,
                chosen_tier TEXT,
                served_model TEXT,
                prompt_tokens INTEGER,
                completion_tokens INTEGER,
                total_tokens INTEGER,
                cost REAL,
                latency_ms INTEGER,
                ttft_ms INTEGER,
                fallbacks INTEGER,
                route_reason TEXT,
                status INTEGER,
                streamed INTEGER,
                cascades INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS requests_user_ts ON requests (user_id, ts);
            CREATE TABLE IF NOT EXISTS feedback (
                request_id TEXT PRIMARY KEY,
                ts REAL NOT NULL,
                user_id TEXT NOT NULL,
                rating TEXT NOT NULL,
                task_class TEXT,
                tier TEXT
            );
            CREATE TABLE IF NOT EXISTS bandit (
                user_id TEXT NOT NULL,
                task_class TEXT NOT NULL,
                tier TEXT NOT NULL,
                alpha REAL NOT NULL,
                beta REAL NOT NULL,
                PRIMARY KEY (user_id, task_class, tier)
            );
            CREATE TABLE IF NOT EXISTS model_bandit (
                user_id TEXT NOT NULL,
                task_type TEXT NOT NULL,
                model TEXT NOT NULL,
                alpha REAL NOT NULL,
                beta REAL NOT NULL,
                PRIMARY KEY (user_id, task_type, model)
            );
            CREATE TABLE IF NOT EXISTS learning_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                user_id TEXT NOT NULL,
                task_type TEXT,
                model TEXT,
                kind TEXT NOT NULL,
                latency_ms INTEGER,
                status INTEGER
            );
            CREATE INDEX IF NOT EXISTS learning_events_ts ON learning_events (ts);
            CREATE TABLE IF NOT EXISTS apps (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                key_hash TEXT NOT NULL UNIQUE,
                created_at REAL NOT NULL,
                last_seen REAL,
                request_count INTEGER NOT NULL DEFAULT 0,
                error_count INTEGER NOT NULL DEFAULT 0,
                last_status INTEGER
            );
            """
        )
        columns = {row[1] for row in self._conn.execute("PRAGMA table_info(requests)")}
        if "cascades" not in columns:
            self._conn.execute("ALTER TABLE requests ADD COLUMN cascades INTEGER NOT NULL DEFAULT 0")
        if "task_type" not in columns:
            self._conn.execute("ALTER TABLE requests ADD COLUMN task_type TEXT")
        self._conn.commit()
        self.purge_events()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def insert_request(self, row: dict) -> None:
        columns = (
            "id",
            "ts",
            "user_id",
            "requested_model",
            "task_class",
            "chosen_tier",
            "served_model",
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
            "cost",
            "latency_ms",
            "ttft_ms",
            "fallbacks",
            "route_reason",
            "status",
            "streamed",
            "cascades",
            "task_type",
        )
        values = tuple(row.get(name) for name in columns)
        # Older callers omit this. A missing count is zero, not NULL.
        values = tuple(0 if name == "cascades" and value is None else value for name, value in zip(columns, values))
        with self._lock:
            self._conn.execute(
                f"INSERT OR REPLACE INTO requests ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
                values,
            )
            self._conn.commit()

    def get_request(self, request_id: str) -> sqlite3.Row | None:
        with self._lock:
            return self._conn.execute("SELECT * FROM requests WHERE id = ?", (request_id,)).fetchone()

    def latest_for_key(self, authorization: str | None) -> sqlite3.Row | None:
        base = key_hash(authorization)
        with self._lock:
            return self._conn.execute(
                """
                SELECT * FROM requests
                WHERE user_id = ? OR user_id LIKE ?
                ORDER BY ts DESC
                LIMIT 1
                """,
                (base, base + ":%"),
            ).fetchone()

    def counts(self, owner: str, task_class: str) -> dict[str, tuple[float, float]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT tier, alpha, beta FROM bandit WHERE user_id = ? AND task_class = ?",
                (owner, task_class),
            ).fetchall()
        return {row["tier"]: (row["alpha"], row["beta"]) for row in rows}

    def model_counts(self, owner: str, task_type: str) -> dict[str, tuple[float, float]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT model, alpha, beta FROM model_bandit WHERE user_id = ? AND task_type = ?",
                (owner, task_type),
            ).fetchall()
        return {row["model"]: (row["alpha"], row["beta"]) for row in rows}

    def same_key(self, stored_user_id: str, authorization: str | None) -> bool:
        return stored_user_id.split(":", 1)[0] == key_hash(authorization)

    def rate(self, row: sqlite3.Row, rating: str) -> None:
        """Record good or bad. Marking the same call again moves the score once."""
        if rating not in ("good", "bad"):
            raise ValueError("rating must be good or bad")
        tier = learning_tier(row["chosen_tier"] or "") or learning_tier(row["requested_model"] or "")
        task_class = row["task_class"] or "other"
        task_type = row["task_type"] if "task_type" in row.keys() and row["task_type"] else class_to_type(task_class)
        model = row["served_model"] or ""
        owner = row["user_id"]
        now = time.time()
        with self._lock:
            previous = self._conn.execute(
                "SELECT rating, tier, task_class FROM feedback WHERE request_id = ?",
                (row["id"],),
            ).fetchone()
            if previous is not None and previous["tier"]:
                self._shift(previous["task_class"] or task_class, owner, previous["tier"], previous["rating"], undo=True)
            if previous is not None and model:
                self._shift_model(task_type, owner, model, previous["rating"], undo=True)
            if tier:
                self._shift(task_class, owner, tier, rating, undo=False)
            if model:
                self._shift_model(task_type, owner, model, rating, undo=False)
                self._insert_event(now, owner, task_type, model, rating, None, row["status"])
            self._conn.execute(
                """
                INSERT INTO feedback (request_id, ts, user_id, rating, task_class, tier)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(request_id) DO UPDATE SET
                    ts = excluded.ts,
                    rating = excluded.rating,
                    task_class = excluded.task_class,
                    tier = excluded.tier
                """,
                (row["id"], now, owner, rating, task_class, tier),
            )
            self._conn.commit()

    def report(self, since: float | None = None) -> dict:
        """Totals for the cost page. `since` defaults to the last 7 days."""
        until = time.time()
        if since is None:
            since = until - 7 * 24 * 60 * 60
        with self._lock:
            request_rows = [
                dict(row)
                for row in self._conn.execute(
                    "SELECT * FROM requests WHERE ts >= ? AND ts <= ? ORDER BY ts DESC",
                    (since, until),
                ).fetchall()
            ]
            mark_rows = [
                dict(row)
                for row in self._conn.execute(
                    "SELECT rating FROM feedback WHERE ts >= ? AND ts <= ?",
                    (since, until),
                ).fetchall()
            ]
            app_rows = [
                (str(row["key_hash"] or ""), str(row["name"] or "").strip())
                for row in self._conn.execute("SELECT name, key_hash FROM apps").fetchall()
            ]
        latencies = [row["latency_ms"] for row in request_rows if row["latency_ms"] is not None]
        cost = 0.0
        cost_missing = 0
        tokens = 0
        prompt_tokens = 0
        completion_tokens = 0
        fallbacks = 0
        cascades = 0
        for row in request_rows:
            if row["cost"] is None:
                cost_missing += 1
            else:
                cost += float(row["cost"])
            if row["total_tokens"] is not None:
                tokens += int(row["total_tokens"])
            if row["prompt_tokens"] is not None:
                prompt_tokens += int(row["prompt_tokens"])
            if row["completion_tokens"] is not None:
                completion_tokens += int(row["completion_tokens"])
            fallbacks += int(row["fallbacks"] or 0)
            cascades += int(row["cascades"] or 0)
        by_model = _buckets(request_rows, "served_model")
        by_task = _buckets(request_rows, "task_class")
        by_tier = _buckets(request_rows, "chosen_tier")
        keys = sorted({row["user_id"] for row in request_rows})
        app_names = {digest[:16]: name for digest, name in app_rows if len(digest) >= 16 and name}
        # Metadata only: model, app name, status, cost, and wait. No prompt or reply text.
        recent = [
            {
                "id": row["id"],
                "time": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(row["ts"])),
                "app": recent_app_name(row["user_id"], app_names),
                "requested_model": row["requested_model"] or "",
                "task_class": row["task_class"] or "",
                "chosen_tier": row["chosen_tier"] or "",
                "served_model": row["served_model"] or "",
                "tokens": row["total_tokens"],
                "cost": row["cost"],
                "latency_ms": row["latency_ms"],
                "fallbacks": int(row["fallbacks"] or 0),
                "status": row["status"],
            }
            for row in request_rows[:15]
        ]
        summary = {
            "since": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(since)),
            "until": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(until)),
            "requests": len(request_rows),
            "cost": round(cost, 6),
            "cost_missing": cost_missing,
            "tokens": tokens,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "fallbacks": fallbacks,
            "cascades": cascades,
            "avg_latency_ms": int(sum(latencies) / len(latencies)) if latencies else None,
            "median_latency_ms": _median(latencies),
            "by_model": by_model,
            "by_task": by_task,
            "by_tier": by_tier,
            "keys": len(keys),
            "marks": {
                "good": sum(1 for row in mark_rows if row["rating"] == "good"),
                "bad": sum(1 for row in mark_rows if row["rating"] == "bad"),
            },
            "recent": recent,
        }
        summary["paragraph"] = _paragraph(summary)
        return summary

    def _shift(self, task_class: str, owner: str, tier: str, rating: str, undo: bool) -> None:
        delta = -1 if undo else 1
        good = delta if rating == "good" else 0
        bad = delta if rating == "bad" else 0
        current = self._conn.execute(
            "SELECT alpha, beta FROM bandit WHERE user_id = ? AND task_class = ? AND tier = ?",
            (owner, task_class, tier),
        ).fetchone()
        alpha = 1.0 if current is None else float(current["alpha"])
        beta = 1.0 if current is None else float(current["beta"])
        alpha = max(1.0, alpha + good)
        beta = max(1.0, beta + bad)
        self._conn.execute(
            """
            INSERT INTO bandit (user_id, task_class, tier, alpha, beta)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id, task_class, tier) DO UPDATE SET
                alpha = excluded.alpha,
                beta = excluded.beta
            """,
            (owner, task_class, tier, alpha, beta),
        )

    def _shift_model(self, task_type: str, owner: str, model: str, kind: str, undo: bool) -> None:
        if kind in SIGNAL_WINS:
            good, bad = 1, 0
        elif kind in SIGNAL_LOSSES:
            good, bad = 0, 1
        else:
            return
        if undo:
            good, bad = -good, -bad
        current = self._conn.execute(
            "SELECT alpha, beta FROM model_bandit WHERE user_id = ? AND task_type = ? AND model = ?",
            (owner, task_type, model),
        ).fetchone()
        alpha = 1.0 if current is None else float(current["alpha"])
        beta = 1.0 if current is None else float(current["beta"])
        alpha = max(1.0, alpha + good)
        beta = max(1.0, beta + bad)
        self._conn.execute(
            """
            INSERT INTO model_bandit (user_id, task_type, model, alpha, beta)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id, task_type, model) DO UPDATE SET
                alpha = excluded.alpha,
                beta = excluded.beta
            """,
            (owner, task_type, model, alpha, beta),
        )

    def _insert_event(
        self,
        now: float,
        owner: str,
        task_type: str | None,
        model: str | None,
        kind: str,
        latency_ms: int | None,
        status: int | None,
    ) -> None:
        self._conn.execute(
            """
            INSERT INTO learning_events (ts, user_id, task_type, model, kind, latency_ms, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (now, owner, task_type, (model or "")[:200], kind, latency_ms, status),
        )
        # The event may itself be old (a test, or a delayed write). The cap is wall clock.
        self._conn.execute(
            "DELETE FROM learning_events WHERE ts < ?",
            (time.time() - RETENTION_SECONDS,),
        )

    def purge_events(self, now: float | None = None) -> int:
        """Drop raw events older than 90 days. Aggregate counts are kept."""
        moment = time.time() if now is None else now
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM learning_events WHERE ts < ?",
                (moment - RETENTION_SECONDS,),
            )
            self._conn.commit()
            return cursor.rowcount

    def record_signal(
        self,
        owner: str,
        kind: str,
        *,
        task_type: str | None,
        model: str | None,
        latency_ms: int | None = None,
        status: int | None = None,
        now: float | None = None,
    ) -> None:
        """Metadata only. The caller has already refused prompt and reply text."""
        if kind not in SIGNAL_KINDS:
            raise ValueError("unknown learning signal")
        safe_model = (model or "")[:200]
        safe_task = (task_type or "fast_chat")[:40]
        moment = time.time() if now is None else now
        with self._lock:
            if safe_model and kind != "latency":
                self._shift_model(safe_task, owner, safe_model, kind, undo=False)
            self._insert_event(moment, owner, safe_task, safe_model, kind, latency_ms, status)
            self._conn.commit()

    def delete_learning(self, authorization: str | None) -> dict:
        """Wipe this key's events, thumbs, and win/loss counts. Cost history stays."""
        base = key_hash(authorization)
        with self._lock:
            events = self._conn.execute(
                "DELETE FROM learning_events WHERE user_id = ? OR user_id LIKE ?",
                (base, base + ":%"),
            ).rowcount
            scores = self._conn.execute(
                "DELETE FROM model_bandit WHERE user_id = ? OR user_id LIKE ?",
                (base, base + ":%"),
            ).rowcount
            scores += self._conn.execute(
                "DELETE FROM bandit WHERE user_id = ? OR user_id LIKE ?",
                (base, base + ":%"),
            ).rowcount
            marks = self._conn.execute(
                "DELETE FROM feedback WHERE user_id = ? OR user_id LIKE ?",
                (base, base + ":%"),
            ).rowcount
            self._conn.commit()
        return {"events": events, "scores": scores, "marks": marks}

    def register_app(self, name: str) -> dict:
        """Create a per-app key. The raw key is returned once and is not stored."""
        import secrets

        raw = "sk-" + secrets.token_hex(32)
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        app_id = secrets.token_hex(8)
        now = time.time()
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) AS n FROM apps").fetchone()["n"]
            if int(count) >= 100:
                raise ValueError("Too many apps are already connected.")
            self._conn.execute(
                """
                INSERT INTO apps (id, name, key_hash, created_at, last_seen, request_count, error_count, last_status)
                VALUES (?, ?, ?, ?, NULL, 0, 0, NULL)
                """,
                (app_id, name, digest, now),
            )
            self._conn.commit()
        return {"app": name, "key": raw, "key_hash": digest}

    def app_by_token(self, token: str) -> sqlite3.Row | None:
        if not token:
            return None
        digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
        with self._lock:
            return self._conn.execute("SELECT * FROM apps WHERE key_hash = ?", (digest,)).fetchone()

    def note_app(self, key_hash: str, status: int) -> None:
        """Count a call. The prompt and the reply are not written."""
        error = 1 if status >= 400 else 0
        with self._lock:
            self._conn.execute(
                """
                UPDATE apps
                SET last_seen = ?, request_count = request_count + 1,
                    error_count = error_count + ?, last_status = ?
                WHERE key_hash = ?
                """,
                (time.time(), error, int(status), key_hash),
            )
            self._conn.commit()

    def list_apps(self) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT name, last_seen, request_count, error_count, last_status
                FROM apps
                ORDER BY name COLLATE NOCASE
                """
            ).fetchall()
        listed = []
        for row in rows:
            last = row["last_status"]
            status = "working" if last is not None and int(last) < 400 else "not_working"
            listed.append(
                {
                    "name": row["name"],
                    "last_seen": row["last_seen"],
                    "request_count": int(row["request_count"]),
                    "error_count": int(row["error_count"]),
                    "status": status,
                }
            )
        return listed

    def learning_event_count(self, owner: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM learning_events WHERE user_id = ?",
                (owner,),
            ).fetchone()
        return int(row["n"])
