"""Forward calls to LiteLLM, and choose a tier when the model is `auto`.

Every other model name is forwarded unchanged. smart, local, t0, t1, and t2
keep the behavior LiteLLM already has. The response carries a short header
that says why the model was chosen.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass

import httpx
from fastapi import Request
from fastapi.responses import JSONResponse, Response, StreamingResponse

from access import Access, bearer_token
from byok import call_provider, missing_key_message, select_target
from cache_policy import apply_cache_policy
from cascade import (
    failure_signal,
    initial_tier,
    log_cascade,
    next_tier,
    note_cascade,
    note_simple_start,
    stream_has_error,
    stream_has_text,
    stream_timeout,
)
from catalog import adjust_auto_model, block_reason
from classify import classify, task_type as classify_task_type
from direct_provider import (
    FREE_MODEL_NOTICE,
    accepts_free,
    call_openrouter,
    free_model_blocked,
    is_free_model,
    privacy_routing,
    should_call_openrouter,
)
from learn import Choice, choose, choose_model, route_reason
from meter import Meter
from plans import cap_auto_tier, note_plan_tier, platform_key_allowed, tier_allowed
from shortlist import candidate_ids
from store import Store, user_id


CHAT_PATHS = {
    "v1/chat/completions",
    "chat/completions",
    "v1/messages",
    "v1/responses",
}
MODEL_PATHS = {"v1/models", "models"}
# Headers the proxy has to drop so the client and the upstream each set their own.
DROP_HEADERS = {
    "host",
    "content-length",
    "connection",
    "transfer-encoding",
    "accept-encoding",
    "content-encoding",
}


@dataclass
class Pending:
    request_id: str
    user_id: str
    requested_model: str
    task_class: str
    chosen_tier: str
    route_reason: str
    response_headers: dict[str, str]
    rule_tier: str = ""
    cascades: int = 0
    learn: bool = True
    task_type: str = "fast_chat"
    picked_model: str = ""
    app_hash: str = ""
    direct_call: bool = False


def _header_map(headers: httpx.Headers) -> dict[str, str]:
    kept: dict[str, str] = {}
    for name, value in headers.items():
        if name.lower() in DROP_HEADERS:
            continue
        kept[name] = value
    return kept


def _request_headers(request: Request) -> dict[str, str]:
    kept: dict[str, str] = {}
    for name, value in request.headers.items():
        if name.lower() in DROP_HEADERS:
            continue
        kept[name] = value
    return kept


def _usage(payload: object) -> tuple[int | None, int | None, int | None]:
    if not isinstance(payload, dict):
        return None, None, None
    usage = payload.get("usage")
    if not isinstance(usage, dict):
        return None, None, None
    def number(name: str) -> int | None:
        value = usage.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        return int(value)
    return number("prompt_tokens"), number("completion_tokens"), number("total_tokens")


def _usage_from_stream(raw: bytes) -> tuple[int | None, int | None, int | None]:
    prompt = completion = total = None
    for line in raw.decode("utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if not data or data == "[DONE]":
            continue
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            continue
        found = _usage(payload)
        if found != (None, None, None):
            prompt, completion, total = found
    return prompt, completion, total


def _header_int(headers: httpx.Headers, name: str) -> int:
    raw = headers.get(name)
    if raw is None:
        return 0
    try:
        return int(float(raw.strip()))
    except ValueError:
        return 0


def _header_cost(headers: httpx.Headers) -> float | None:
    raw = headers.get("x-litellm-response-cost")
    if raw is None or not raw.strip():
        return None
    try:
        return float(raw.strip())
    except ValueError:
        return None


def _served_model(headers: httpx.Headers, payload: object) -> str:
    named = headers.get("x-litellm-model-name")
    if named:
        return named.strip()
    if isinstance(payload, dict) and isinstance(payload.get("model"), str):
        return payload["model"]
    return ""


def inject_auto(raw: bytes) -> bytes:
    """Add `auto` to the model list so apps that discover models can see it."""
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return raw
    rows = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return raw
    if any(isinstance(row, dict) and row.get("id") == "auto" for row in rows):
        return raw
    rows.append({"id": "auto", "object": "model", "created": 0, "owned_by": "gateway"})
    return json.dumps(payload).encode("utf-8")


def _learning_on(request: Request) -> bool:
    raw = request.headers.get("x-gateway-learn")
    if raw is None:
        return True
    return raw.strip().lower() not in {"0", "false", "off", "no"}


class Gateway:
    def __init__(
        self,
        upstream: str,
        store: Store,
        rng=None,
        catalog: list[dict] | None = None,
        shortlist: dict | None = None,
    ):
        self.upstream = upstream.rstrip("/")
        self.store = store
        self.rng = rng
        self.client: httpx.AsyncClient | None = None
        self.access = Access.from_env()
        self.meter = Meter(self.access.redis)
        self.catalog = catalog
        self.shortlist = shortlist
        # Keys saved from this computer. Not the ones LiteLLM read from .env.
        self.provider_keys: dict[str, str] = {}

    def remember_provider_key(self, provider: str, key: str) -> None:
        cleaned = key.strip()
        if cleaned:
            self.provider_keys[provider] = cleaned

    def openrouter_key(self) -> str:
        return self.provider_keys.get("openrouter", "").strip()

    async def startup(self) -> None:
        # The upstream has its own per-model timeouts. This client has to wait
        # longer than the slowest chain (a couple of cloud tries, then Ollama).
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(600.0, connect=10.0))

    async def shutdown(self) -> None:
        if self.client is not None:
            await self.client.aclose()

    def prepare(
        self,
        body: bytes,
        authorization: str | None,
        *,
        remember_cache: bool = True,
        learn: bool = True,
    ) -> tuple[bytes, Pending | None]:
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            return body, None
        if not isinstance(payload, dict):
            return body, None
        # Namespace keeps two gateway passwords from sharing a saved answer.
        # Streaming and non-zero temperature are marked do-not-store.
        # /v1/messages is Anthropic-shaped. Its own cache_control blocks must
        # stay, and the OpenAI `cache` object does not belong on that body.
        if remember_cache:
            apply_cache_policy(payload, authorization)
        requested = payload.get("model")
        requested_name = requested.strip() if isinstance(requested, str) else ""
        rule = classify(payload)
        kind = classify_task_type(payload)
        end_user = payload.get("user") if isinstance(payload.get("user"), str) else None
        owner = user_id(authorization, end_user)
        choice: Choice | None = None
        chosen = requested_name
        if requested_name.lower() == "auto":
            choice = choose(rule, self.store.counts(owner, rule.task_class), self.rng)
            chosen = initial_tier(rule.task_class, choice.tier, payload)
            payload["model"] = chosen
        body = json.dumps(payload).encode("utf-8")
        reason = route_reason(rule, requested_name or "(none)", choice)
        if choice is not None and chosen != choice.tier:
            reason = note_simple_start(reason, choice.tier, chosen)
        request_id = uuid.uuid4().hex
        headers = {
            "x-gateway-request-id": request_id,
            "x-gateway-route": chosen or "(none)",
            "x-gateway-task": rule.task_class,
            "x-gateway-route-reason": reason,
        }
        return body, Pending(
            request_id=request_id,
            user_id=owner,
            requested_model=requested_name,
            task_class=rule.task_class,
            chosen_tier=chosen,
            route_reason=reason,
            response_headers=headers,
            rule_tier=rule.tier,
            cascades=0,
            learn=learn,
            task_type=kind,
        )

    def _save(
        self,
        pending: Pending | None,
        status: int,
        headers: httpx.Headers | None,
        raw: bytes,
        started: float,
        ttft: float | None,
        streamed: bool,
    ) -> None:
        if pending is None:
            return
        payload: object = None
        if streamed:
            prompt, completion, total = _usage_from_stream(raw)
        else:
            try:
                payload = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                payload = None
            prompt, completion, total = _usage(payload)
        served = _served_model(headers, payload) if headers is not None else ""
        now = time.perf_counter()
        try:
            self.store.insert_request(
                {
                    "id": pending.request_id,
                    "ts": time.time(),
                    "user_id": pending.user_id,
                    "requested_model": pending.requested_model,
                    "task_class": pending.task_class,
                    "chosen_tier": pending.chosen_tier,
                    "served_model": served,
                    "prompt_tokens": prompt,
                    "completion_tokens": completion,
                    "total_tokens": total,
                    "cost": _header_cost(headers) if headers is not None else None,
                    "latency_ms": int((now - started) * 1000),
                    "ttft_ms": None if ttft is None else int((ttft - started) * 1000),
                    "fallbacks": _header_int(headers, "x-litellm-attempted-fallbacks") if headers is not None else 0,
                    "route_reason": pending.route_reason,
                    "status": status,
                    "streamed": 1 if streamed else 0,
                    "cascades": pending.cascades,
                    "task_type": pending.task_type,
                }
            )
            if pending.learn:
                self._observe(pending, status, served, int((now - started) * 1000))
            if pending.app_hash:
                self.store.note_app(pending.app_hash, status)
        except Exception:
            # A bookkeeping failure must not hide the model's answer.
            return

    def _url(self, request: Request) -> str:
        url = self.upstream + request.url.path
        if request.url.query:
            url = url + "?" + request.url.query
        return url

    async def _send(
        self,
        request: Request,
        body: bytes,
        authorization: str | None = None,
    ) -> httpx.Response:
        assert self.client is not None
        headers = _request_headers(request)
        if authorization:
            headers = {name: value for name, value in headers.items() if name.lower() != "authorization"}
            headers["authorization"] = authorization
        return await self.client.send(
            self.client.build_request(
                request.method,
                self._url(request),
                headers=headers,
                content=body,
            ),
            stream=True,
        )

    def _offline(self, pending: Pending | None, started: float) -> JSONResponse:
        self._save(pending, 502, None, b"", started, None, False)
        headers = pending.response_headers if pending is not None else {}
        return JSONResponse(
            {
                "error": {
                    "message": "The model server is not answering. From the gateway folder run: docker compose up -d",
                    "type": "gateway_error",
                }
            },
            status_code=502,
            headers=headers,
        )

    def _mark_cascade(self, pending: Pending, payload: dict, signal: str) -> bytes:
        old = pending.chosen_tier
        new = next_tier(pending.requested_model, pending.task_class, old, payload)
        if new is None:
            raise RuntimeError("cascade was marked without a next tier")
        payload["model"] = new
        pending.chosen_tier = new
        pending.cascades += 1
        pending.route_reason = note_cascade(pending.route_reason, old, signal, new)
        pending.response_headers["x-gateway-route"] = new
        pending.response_headers["x-gateway-route-reason"] = pending.route_reason
        log_cascade(old, signal, new, pending.task_class)
        return json.dumps(payload).encode("utf-8")

    def _can_step_up(self, pending: Pending | None, payload: dict | None) -> bool:
        if pending is None or payload is None or pending.cascades or pending.direct_call:
            return False
        return next_tier(pending.requested_model, pending.task_class, pending.chosen_tier, payload) is not None

    async def _open(
        self,
        request: Request,
        body: bytes,
        pending: Pending | None,
        payload: dict | None,
        started: float,
        authorization: str | None = None,
    ):
        """Open the upstream call. On a dead connection, step up once if that is allowed."""
        signal = "error"
        try:
            return await self._send(request, body, authorization), body
        except httpx.TimeoutException:
            signal = "timeout"
        except httpx.HTTPError:
            signal = "error"
        if self._can_step_up(pending, payload):
            assert pending is not None and payload is not None
            body = self._mark_cascade(pending, payload, signal)
            try:
                return await self._send(request, body, authorization), body
            except httpx.HTTPError:
                return self._offline(pending, started), body
        return self._offline(pending, started), body

    async def _hosted(
        self,
        request: Request,
        pending: Pending | None,
        payload: dict | None,
        path: str,
        started: float,
    ) -> Response | None:
        """Caps and bring-your-own keys. None means the local LiteLLM path stays as it was."""
        plan = self.access.lookup(request.headers.get("authorization"))
        if plan is None:
            return None
        headers = pending.response_headers if pending is not None else {}
        if plan.get("unavailable"):
            return JSONResponse(
                {"error": {"message": "The usage meter is not answering. Try again in a moment.", "type": "gateway_error"}},
                status_code=503,
                headers=headers,
            )
        if plan.get("unregistered"):
            return JSONResponse(
                {"error": {"message": "This key is not registered. Create it on the API keys page.", "type": "gateway_error"}},
                status_code=401,
                headers=headers,
            )
        if pending is not None and payload is not None and pending.requested_model.lower() == "auto":
            new = cap_auto_tier(pending.chosen_tier, pending.rule_tier, plan.get("maxAutoTier"))
            if new != pending.chosen_tier:
                pending.route_reason = note_plan_tier(
                    pending.route_reason, pending.chosen_tier, new, str(plan.get("maxAutoTier") or "")
                )
                pending.chosen_tier = new
                pending.response_headers["x-gateway-route"] = new
                pending.response_headers["x-gateway-route-reason"] = pending.route_reason
                payload["model"] = new
        elif pending is not None and not tier_allowed(pending.requested_model, plan.get("maxAutoTier")):
            return JSONResponse(
                {
                    "error": {
                        "message": f"This plan stops at {plan.get('maxAutoTier')}.",
                        "type": "gateway_error",
                    }
                },
                status_code=403,
                headers=headers,
            )
        hours = self.meter.allow(plan)
        if not hours.allowed:
            self._save(pending, 429, None, b"", started, None, False)
            return JSONResponse(
                {"error": {"message": hours.message, "type": "rate_limit"}},
                status_code=429,
                headers=headers,
            )
        rate = self.meter.rpm(plan)
        if not rate.allowed:
            self._save(pending, 429, None, b"", started, None, False)
            return JSONResponse(
                {"error": {"message": rate.message, "type": "rate_limit"}},
                status_code=429,
                headers=headers,
            )
        tier = pending.chosen_tier if pending is not None else ""
        normalized = {"smart": "t1", "local": "t0"}.get(tier.lower(), tier.lower())
        if normalized in ("t0", "local"):
            return None
        if path not in ("chat/completions", "v1/chat/completions") or payload is None or self.client is None:
            if platform_key_allowed(plan):
                return None
            return JSONResponse(
                {
                    "error": {
                        "message": "Hosted calls use /v1/chat/completions with your own provider key.",
                        "type": "gateway_error",
                    }
                },
                status_code=400,
                headers=headers,
            )
        keys = self.access.keys_for(str(plan.get("userId") or ""))
        target = select_target(normalized, keys)
        if target is None:
            if platform_key_allowed(plan):
                return None
            return JSONResponse(
                {"error": {"message": missing_key_message(normalized), "type": "gateway_error"}},
                status_code=402,
                headers=headers,
            )
        status, raw, content_type = await call_provider(self.client, target, keys[target.provider], payload)
        self._save(pending, status, None, raw, started, None, bool(payload.get("stream")))
        merged = dict(headers)
        merged["content-type"] = content_type
        return Response(content=raw, status_code=status, headers=merged)

    async def _peek_stream(self, upstream: httpx.Response):
        """Read until the first answer token, a failure, or the fast timeout.

        Bytes returned here have not been sent to the client yet. The same
        iterator must be used for the rest of the body, because httpx will
        not restart a stream.
        """
        agen = upstream.aiter_bytes()
        if upstream.status_code >= 400:
            signal = "timeout" if upstream.status_code in (408, 504) else "error"
            return [], signal, agen
        deadline = time.perf_counter() + stream_timeout()
        buffered: list[bytes] = []
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return buffered, "timeout", agen
            try:
                chunk = await asyncio.wait_for(self._next_chunk(agen), remaining)
            except TimeoutError:
                return buffered, "timeout", agen
            if chunk is None:
                raw = b"".join(buffered)
                if stream_has_text(raw):
                    return buffered, None, agen
                return buffered, "empty", agen
            buffered.append(chunk)
            raw = b"".join(buffered)
            if stream_has_text(raw):
                return buffered, None, agen
            if stream_has_error(raw):
                return buffered, "error", agen

    @staticmethod
    async def _next_chunk(agen: AsyncIterator[bytes]) -> bytes | None:
        try:
            return await agen.__anext__()
        except StopAsyncIteration:
            return None

    def _catalog_block(self, pending: Pending) -> JSONResponse | None:
        reason = block_reason(self.catalog, pending.requested_model)
        if not reason:
            return None
        self._save(pending, 400, None, b"", time.perf_counter(), None, False)
        return JSONResponse(
            {"error": {"message": reason, "type": "gateway_error"}},
            status_code=400,
            headers=pending.response_headers,
        )

    def _catalog_adjust(self, request: Request, pending: Pending, payload: dict) -> None:
        if not self.catalog or pending.requested_model.lower() != "auto":
            return
        plan = self.access.lookup(request.headers.get("authorization"))
        if plan is not None and not plan.get("userId"):
            return
        owned = None
        max_tier = None
        if plan is not None:
            owned = set(self.access.keys_for(str(plan.get("userId") or "")).keys())
            raw_cap = plan.get("maxAutoTier")
            max_tier = raw_cap if isinstance(raw_cap, str) else None
        new = adjust_auto_model(
            self.catalog,
            pending.chosen_tier,
            owned,
            max_tier,
            specific_id=plan is None,
        )
        if new == pending.chosen_tier:
            return
        pending.route_reason = " ".join(f"{pending.route_reason} catalog:{new}".split())[:300]
        pending.chosen_tier = new
        pending.response_headers["x-gateway-route"] = new
        pending.response_headers["x-gateway-route-reason"] = pending.route_reason
        payload["model"] = new

    def _observe(self, pending: Pending, status: int, served: str, latency_ms: int) -> None:
        """Log latency, and count an error or timeout. Never stores text."""
        if status in (408, 504) or latency_ms >= 60_000:
            kind = "timeout"
        elif status >= 400:
            kind = "error"
        else:
            kind = "latency"
        model = pending.picked_model or served
        self.store.record_signal(
            pending.user_id,
            kind,
            task_type=pending.task_type,
            model=model,
            latency_ms=latency_ms,
            status=status,
        )

    def _apply_shortlist(self, request: Request, pending: Pending, payload: dict) -> None:
        """Pick one shortlist model for this user. Leave the tier name when none fits."""
        if not pending.learn or not self.shortlist or not self.catalog:
            return
        if pending.requested_model.lower() != "auto":
            return
        if pending.chosen_tier not in {"t0", "t1", "t2", "t3", "fast"}:
            return
        plan = self.access.lookup(request.headers.get("authorization"))
        if plan is not None and not plan.get("userId"):
            return
        owned = None
        max_tier = None
        if plan is not None:
            owned = set(self.access.keys_for(str(plan.get("userId") or "")).keys())
            raw_cap = plan.get("maxAutoTier")
            max_tier = raw_cap if isinstance(raw_cap, str) else None
        options = candidate_ids(
            self.shortlist,
            pending.task_type,
            pending.chosen_tier,
            self.catalog,
            owned,
            max_tier,
        )
        picked = choose_model(options, self.store.model_counts(pending.user_id, pending.task_type), self.rng)
        if not picked:
            return
        # Privacy-safe routing leaves :free models out unless the caller named one.
        if is_free_model(picked):
            return
        pending.picked_model = picked
        pending.route_reason = " ".join(f"{pending.route_reason} model={picked}".split())[:300]
        pending.response_headers["x-gateway-route-reason"] = pending.route_reason
        pending.response_headers["x-gateway-picked-model"] = picked
        payload["model"] = picked

    async def provider_test(self, request: Request) -> JSONResponse:
        authorization = request.headers.get("authorization")
        if authorization is None or not authorization.lower().startswith("bearer ") or not authorization.split(" ", 1)[1].strip():
            return JSONResponse({"ok": False, "message": "Add the gateway password in Settings first."}, status_code=401)
        try:
            payload = await request.json()
        except Exception:
            payload = None
        provider = payload.get("provider") if isinstance(payload, dict) else None
        if not isinstance(provider, str) or not provider.strip():
            return JSONResponse({"ok": False, "message": "Name the provider to test."}, status_code=400)
        provider = provider.strip().lower()
        row = None
        for candidate in self.catalog or []:
            if candidate.get("provider") == provider and candidate.get("routable") and not candidate.get("deprecated"):
                row = candidate
                break
        if row is None:
            return JSONResponse(
                {
                    "ok": False,
                    "provider": provider,
                    "message": "This provider is not turned on yet. Add the key, uncomment it if the guide says to, restart the gateway, and try again.",
                }
            )
        if self.client is None:
            return JSONResponse({"ok": False, "provider": provider, "message": "The gateway is still starting."}, status_code=503)
        body = json.dumps(
            {
                "model": row["id"],
                "stream": False,
                "max_tokens": 16,
                "messages": [{"role": "user", "content": "Reply with the single word: pong"}],
            }
        ).encode("utf-8")
        try:
            upstream = await self.client.send(
                self.client.build_request(
                    "POST",
                    self.upstream + "/v1/chat/completions",
                    headers={
                        "authorization": authorization,
                        "content-type": "application/json",
                    },
                    content=body,
                ),
                stream=False,
            )
        except httpx.HTTPError:
            return JSONResponse(
                {"ok": False, "provider": provider, "model": row["id"], "message": "The model server did not answer."}
            )
        ok = upstream.status_code == 200
        message = "Working." if ok else "The test call did not succeed. Check the key in the env file, then restart the gateway."
        return JSONResponse({"ok": ok, "provider": provider, "model": row["id"], "message": message})

    async def forward(self, request: Request) -> Response:
        if self.client is None:
            return JSONResponse(
                {"error": {"message": "The gateway is still starting.", "type": "gateway_error"}},
                status_code=503,
            )
        incoming = await request.body()
        path = request.url.path.lstrip("/")
        pending = None
        payload = None
        body = incoming
        if request.method == "POST" and path in CHAT_PATHS:
            body, pending = self.prepare(
                incoming,
                request.headers.get("authorization"),
                remember_cache=path != "v1/messages",
                learn=_learning_on(request),
            )
            try:
                payload = json.loads(body)
            except json.JSONDecodeError:
                payload = None
        started = time.perf_counter()
        if request.method == "POST" and path in CHAT_PATHS and isinstance(payload, dict) and pending is not None:
            refused = self._catalog_block(pending)
            if refused is not None:
                return refused
            self._catalog_adjust(request, pending, payload)
            self._apply_shortlist(request, pending, payload)
        hosted = None
        if request.method == "POST" and path in CHAT_PATHS:
            hosted = await self._hosted(
                request,
                pending,
                payload if isinstance(payload, dict) else None,
                path,
                started,
            )
        if hosted is not None:
            return hosted
        if request.method == "POST" and path in CHAT_PATHS and isinstance(payload, dict):
            body = json.dumps(payload).encode("utf-8")
        token = bearer_token(request.headers.get("authorization"))
        app_row = self.store.app_by_token(token) if token else None
        upstream_authorization = None
        if app_row is not None:
            if pending is not None:
                pending.app_hash = str(app_row["key_hash"])
            if self.access.master_key:
                upstream_authorization = f"Bearer {self.access.master_key}"
        direct = None
        if request.method == "POST" and path in CHAT_PATHS:
            direct = await self._direct_openrouter(
                request,
                pending,
                payload if isinstance(payload, dict) else None,
                started,
            )
            if isinstance(direct, JSONResponse):
                return direct
        if direct is not None:
            opened = direct
        else:
            opened, body = await self._open(
                request,
                body,
                pending,
                payload if isinstance(payload, dict) else None,
                started,
                upstream_authorization,
            )
        if isinstance(opened, JSONResponse):
            return opened
        upstream = opened
        if isinstance(payload, dict):
            try:
                payload = json.loads(body)
            except json.JSONDecodeError:
                payload = None
        stepped = await self._maybe_cascade(
            request,
            upstream,
            pending,
            payload if isinstance(payload, dict) else None,
            started,
            None if direct is not None else upstream_authorization,
        )
        if isinstance(stepped, JSONResponse):
            return stepped
        upstream, preloaded, agen = stepped
        extra = pending.response_headers if pending is not None else {}
        content_type = upstream.headers.get("content-type", "")
        merged = _header_map(upstream.headers)
        merged.update(extra)
        if "text/event-stream" in content_type.lower() or preloaded:
            return StreamingResponse(
                self._stream(upstream, pending, started, preloaded, agen),
                status_code=upstream.status_code,
                headers=merged,
                media_type=content_type or "text/event-stream",
            )
        raw = await upstream.aread()
        await upstream.aclose()
        self._save(pending, upstream.status_code, upstream.headers, raw, started, None, False)
        if path in MODEL_PATHS and upstream.status_code == 200:
            raw = inject_auto(raw)
        return Response(content=raw, status_code=upstream.status_code, headers=merged)

    async def _direct_openrouter(self, request: Request, pending: Pending | None, payload: dict | None, started: float):
        """Use a saved OpenRouter key. None means the LiteLLM path stays as it was."""
        if self.client is None or not isinstance(payload, dict) or pending is None:
            return None
        requested = pending.requested_model or str(payload.get("model") or "")
        key = self.openrouter_key()
        if not should_call_openrouter(requested, bool(key)):
            return None
        current = payload.get("model") if isinstance(payload.get("model"), str) else ""
        if privacy_routing() and is_free_model(current) and not is_free_model(requested):
            payload["model"] = "auto"
            current = "auto"
        accepted = accepts_free(request.headers.get("x-gateway-accept-free"))
        if free_model_blocked(requested, accepted) or free_model_blocked(current, accepted):
            self._save(pending, 409, None, b"", started, None, False)
            return JSONResponse(
                {"error": {"message": FREE_MODEL_NOTICE, "code": "free_model_notice", "type": "gateway_error"}},
                status_code=409,
                headers=pending.response_headers,
            )
        pending.direct_call = True
        try:
            upstream = await call_openrouter(self.client, key, payload)
        except httpx.HTTPError:
            return self._offline(pending, started)
        pending.route_reason = " ".join(f"{pending.route_reason} openrouter-direct".split())[:300]
        pending.response_headers["x-gateway-route-reason"] = pending.route_reason
        return upstream

    async def _maybe_cascade(
        self,
        request: Request,
        upstream: httpx.Response,
        pending: Pending | None,
        payload: dict | None,
        started: float,
        authorization: str | None = None,
    ):
        """Step up one tier before any token is sent. Otherwise keep this response."""
        content_type = upstream.headers.get("content-type", "")
        streaming = "text/event-stream" in content_type.lower()
        if not self._can_step_up(pending, payload):
            return upstream, [], None
        assert pending is not None and payload is not None
        if streaming:
            buffered, signal, agen = await self._peek_stream(upstream)
            if signal is None:
                return upstream, buffered, agen
            await upstream.aclose()
            body = self._mark_cascade(pending, payload, signal)
            try:
                nxt = await self._send(request, body, authorization)
            except httpx.HTTPError:
                return self._offline(pending, started)
            return nxt, [], None
        raw = await upstream.aread()
        signal = failure_signal(payload, upstream.status_code, raw)
        if signal is None:
            # The body was already read. Hand it back so the caller can read it once.
            return _Replay(upstream, raw), [], None
        await upstream.aclose()
        body = self._mark_cascade(pending, payload, signal)
        try:
            nxt = await self._send(request, body, authorization)
        except httpx.HTTPError:
            return self._offline(pending, started)
        return nxt, [], None

    async def _stream(
        self,
        upstream: httpx.Response,
        pending: Pending | None,
        started: float,
        preloaded: list[bytes] | None = None,
        agen: AsyncIterator[bytes] | None = None,
    ) -> AsyncIterator[bytes]:
        ttft: float | None = None
        tail = b""
        if agen is None:
            agen = upstream.aiter_bytes()
        try:
            for chunk in preloaded or []:
                if ttft is None and chunk:
                    ttft = time.perf_counter()
                tail = (tail + chunk)[-65536:]
                yield chunk
            async for chunk in agen:
                if ttft is None and chunk:
                    ttft = time.perf_counter()
                tail = (tail + chunk)[-65536:]
                yield chunk
        finally:
            self._save(pending, upstream.status_code, upstream.headers, tail, started, ttft, True)
            await upstream.aclose()


class _Replay:
    """A response whose body was already read, so the caller can read it once more."""

    def __init__(self, upstream: httpx.Response, raw: bytes):
        self.status_code = upstream.status_code
        self.headers = upstream.headers
        self._raw = raw
        self._upstream = upstream

    async def aread(self) -> bytes:
        return self._raw

    async def aclose(self) -> None:
        await self._upstream.aclose()
