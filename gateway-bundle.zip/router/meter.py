"""Active hours and a per-minute request cap, stored in Redis.

An active hour is 12 five-minute slices. A slice counts once, the first time
a request lands in it. The next request in a slice that is already open is
free. Past the plan's slices, the answer is 429 and names the reset time.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone


SLICE_MINUTES = 5


@dataclass(frozen=True)
class Decision:
    allowed: bool
    message: str


def _text(value: object) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return "" if value is None else str(value)


class Meter:
    def __init__(self, redis=None):
        self.redis = redis

    def allow(self, plan: dict, now: datetime | None = None) -> Decision:
        if self.redis is None:
            return Decision(True, "")
        clock = now or datetime.now(timezone.utc)
        if clock.tzinfo is None:
            clock = clock.replace(tzinfo=timezone.utc)
        day = clock.strftime("%Y-%m-%d")
        slice_id = str((clock.hour * 60 + clock.minute) // SLICE_MINUTES)
        key = f"gateway:active:{plan['userId']}:{day}"
        limit = int(plan.get("activeSlices") or 0)
        if self.redis.sismember(key, slice_id):
            return Decision(True, "")
        if self.redis.scard(key) >= limit:
            reset = (clock.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)).strftime(
                "%Y-%m-%d %H:%M UTC"
            )
            return Decision(False, f"Active hours for today are used up. Resets at {reset}.")
        self.redis.sadd(key, slice_id)
        self.redis.expire(key, 60 * 60 * 48)
        return Decision(True, "")

    def rpm(self, plan: dict, now: datetime | None = None) -> Decision:
        if self.redis is None:
            return Decision(True, "")
        limit = int(plan.get("rpm") or 0)
        if limit <= 0:
            return Decision(True, "")
        clock = now or datetime.now(timezone.utc)
        if clock.tzinfo is None:
            clock = clock.replace(tzinfo=timezone.utc)
        key = f"gateway:rpm:{plan.get('keyHash') or plan['userId']}:{clock.strftime('%Y%m%d%H%M')}"
        count = int(self.redis.incr(key))
        if count == 1:
            self.redis.expire(key, 120)
        if count > limit:
            reset = (clock.replace(second=0, microsecond=0) + timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M UTC")
            return Decision(False, f"Too many requests this minute. Resets at {reset}.")
        return Decision(True, "")


class MemoryRedis:
    """Enough of Redis for the meter tests. Not used in production."""

    def __init__(self):
        self.sets: dict[str, set[str]] = {}
        self.values: dict[str, str] = {}
        self.numbers: dict[str, int] = {}

    def sadd(self, key: str, member: str) -> int:
        self.sets.setdefault(key, set()).add(_text(member))
        return 1

    def sismember(self, key: str, member: str) -> bool:
        return _text(member) in self.sets.get(key, set())

    def scard(self, key: str) -> int:
        return len(self.sets.get(key, set()))

    def expire(self, key: str, seconds: int) -> bool:
        return True

    def incr(self, key: str) -> int:
        self.numbers[key] = self.numbers.get(key, 0) + 1
        return self.numbers[key]

    def get(self, key: str):
        return self.values.get(key)

    def set(self, key: str, value: str) -> bool:
        self.values[key] = value
        return True

    def delete(self, key: str) -> int:
        self.values.pop(key, None)
        return 1
