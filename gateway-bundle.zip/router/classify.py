"""Sort one chat into a task class and suggest a tier.

This is a keyword check, not another model call, so it does not add a wait.
The plan's 16 task classes were not written down in this repo, so the list
below is the v0 set: the kinds of chat Aaron actually sends, plus the ones
the product notes named (coding, quick chat, summarize, extract, hard
reasoning, and tool or agent calls).

Learning can still pick a different tier. See learn.py.
"""

from __future__ import annotations

from dataclasses import dataclass


TASK_CLASSES = (
    "quick_chat",
    "coding",
    "code_review",
    "debug",
    "summarize",
    "extract",
    "rewrite",
    "translate",
    "hard_reasoning",
    "tool_agent",
    "planning",
    "creative",
    "classify",
    "long_context",
    "data_qa",
    "other",
)

# A prompt longer than this, in the user's own words, is a long-context job.
# The system prompt is ignored so an agent's standing instructions do not
# push every short question into the long class.
LONG_CONTEXT_CHARS = 8000

# No keyword, and shorter than this, is treated as a quick chat.
SHORT_CHAT_CHARS = 280


@dataclass(frozen=True)
class Rule:
    task_class: str
    tier: str
    confidence: float
    reason: str


# confidence is 0 to 1. A higher number means the rule starts further ahead
# of the other tiers. It is not a lock. Enough bad marks can pass it.
RULES: dict[str, Rule] = {
    "quick_chat": Rule(
        "quick_chat",
        "fast",
        0.92,
        "Short chat goes to the fast lane (Gemini Flash-Lite).",
    ),
    "summarize": Rule(
        "summarize",
        "fast",
        0.80,
        "Summaries are a good fit for the fast lane.",
    ),
    "extract": Rule(
        "extract",
        "fast",
        0.84,
        "Pulling facts out of text is a good fit for the fast lane.",
    ),
    "translate": Rule(
        "translate",
        "fast",
        0.78,
        "Translation goes to the fast lane.",
    ),
    "classify": Rule(
        "classify",
        "fast",
        0.86,
        "Labeling text goes to the fast lane.",
    ),
    "data_qa": Rule(
        "data_qa",
        "fast",
        0.64,
        "Questions about pasted data start on the fast lane.",
    ),
    "rewrite": Rule(
        "rewrite",
        "t1",
        0.55,
        "Rewrites start on the free cloud pool.",
    ),
    "creative": Rule(
        "creative",
        "t1",
        0.50,
        "Creative writing starts on the free cloud pool.",
    ),
    "other": Rule(
        "other",
        "t1",
        0.35,
        "This did not match a task, so it starts on the free cloud pool.",
    ),
    "coding": Rule(
        "coding",
        "t2",
        0.72,
        "Coding goes to the mid model (Gemini 3.8 Flash).",
    ),
    "code_review": Rule(
        "code_review",
        "t2",
        0.68,
        "Code review goes to the mid model.",
    ),
    "debug": Rule(
        "debug",
        "t2",
        0.74,
        "Debugging goes to the mid model.",
    ),
    "hard_reasoning": Rule(
        "hard_reasoning",
        "t2",
        0.90,
        "Hard reasoning goes to the mid model.",
    ),
    "tool_agent": Rule(
        "tool_agent",
        "t2",
        0.82,
        "Tool and agent calls go to the mid model, which can use tools.",
    ),
    "planning": Rule(
        "planning",
        "t2",
        0.70,
        "Planning goes to the mid model.",
    ),
    "long_context": Rule(
        "long_context",
        "t2",
        0.75,
        "Long inputs go to the mid model.",
    ),
}


# First match with the most hits wins. On a tie, the earlier class wins,
# so "review this bug" stays a review and "summarize this code" stays a summary.
_PHRASES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("debug", ("traceback", "stack trace", "exception", "debug this", "fails with", "error:", "bug")),
    ("code_review", ("code review", "review this", "pull request", "look over this code")),
    ("summarize", ("summarize", "summarise", "tl;dr", "tldr", "sum up", "brief summary")),
    ("extract", ("extract", "pull out", "as json")),
    ("translate", ("translate", "to spanish", "to french", "to english", "to german", "in spanish")),
    ("hard_reasoning", ("prove that", "theorem", "puzzle", "riddle", "reason carefully", "show your work")),
    ("planning", ("make a plan", "roadmap", "break this into steps", "architecture")),
    ("creative", ("short story", "write a story", "write a poem", "poem", "fiction", "write a song")),
    ("rewrite", ("rewrite", "rephrase", "more formal", "more concise")),
    ("classify", ("classify", "categorize", "categorise", "which category", "label these")),
    ("data_qa", ("this table", "csv", "spreadsheet", "which row", "which column")),
    (
        "coding",
        (
            "```",
            "write a function",
            "python function",
            "javascript",
            "typescript",
            "refactor",
            "implement this",
            "sql query",
            "function that",
        ),
    ),
)


def message_text(message: object) -> str:
    if not isinstance(message, dict):
        return ""
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict) and isinstance(part.get("text"), str):
                parts.append(part["text"])
        return "\n".join(parts)
    return ""


def last_user_text(messages: object) -> str:
    if not isinstance(messages, list):
        return ""
    for message in reversed(messages):
        if isinstance(message, dict) and message.get("role") == "user":
            return message_text(message)
    return "\n".join(message_text(message) for message in messages)


def request_text(body: dict) -> str:
    messages = body.get("messages")
    if isinstance(messages, list) and messages:
        return last_user_text(messages)
    incoming = body.get("input")
    if isinstance(incoming, str):
        return incoming
    if isinstance(incoming, list):
        return last_user_text(incoming)
    return ""


def has_tools(body: dict) -> bool:
    if body.get("tools") or body.get("functions"):
        return True
    messages = body.get("messages")
    if not isinstance(messages, list):
        messages = body.get("input") if isinstance(body.get("input"), list) else []
    for message in messages:
        if not isinstance(message, dict):
            continue
        if message.get("role") in ("tool", "function"):
            return True
        if message.get("tool_calls") or message.get("function_call"):
            return True
    return False


# The coarser labels the shortlist and the per-model bandit use.
TASK_TYPES = ("coding", "reasoning", "long_doc", "vision", "fast_chat")

_CODE_HINTS = (
    "```",
    "write a function",
    "function that",
    "refactor",
    "sql query",
    "traceback",
    "stack trace",
    "pull request",
    "debug this",
    "python function",
)
_REASON_HINTS = (
    "prove that",
    "theorem",
    "reason carefully",
    "show your work",
    "puzzle",
    "riddle",
    "make a plan",
    "break this into steps",
)


def has_vision(body: dict) -> bool:
    messages = body.get("messages")
    if not isinstance(messages, list):
        messages = body.get("input") if isinstance(body.get("input"), list) else []
    for message in messages:
        if not isinstance(message, dict):
            continue
        if message.get("images"):
            return True
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict):
                continue
            kind = str(part.get("type") or "")
            if kind in {"image_url", "image", "input_image"} or isinstance(part.get("image_url"), (dict, str)):
                return True
    return False


def task_type(body: dict) -> str:
    """coding, reasoning, long_doc, vision, or fast_chat. Keyword check only."""
    if has_vision(body):
        return "vision"
    text = request_text(body)
    lowered = text.lower()
    if any(hint in lowered for hint in _CODE_HINTS) or has_tools(body):
        return "coding"
    if any(hint in lowered for hint in _REASON_HINTS):
        return "reasoning"
    if len(text) >= LONG_CONTEXT_CHARS:
        return "long_doc"
    return "fast_chat"


def class_to_type(task_class: str | None) -> str:
    if task_class in {"coding", "code_review", "debug", "tool_agent"}:
        return "coding"
    if task_class in {"hard_reasoning", "planning"}:
        return "reasoning"
    if task_class == "long_context":
        return "long_doc"
    return "fast_chat"


def classify(body: dict) -> Rule:
    """Pick the rule for this request body. Never raises on odd JSON."""
    if has_tools(body):
        return RULES["tool_agent"]
    text = request_text(body)
    if len(text) >= LONG_CONTEXT_CHARS:
        return RULES["long_context"]
    lowered = text.lower()
    best_name = ""
    best_hits = 0
    for name, phrases in _PHRASES:
        hits = sum(1 for phrase in phrases if phrase in lowered)
        if hits > best_hits:
            best_hits = hits
            best_name = name
    if not best_name:
        if len(text.strip()) <= SHORT_CHAT_CHARS:
            return RULES["quick_chat"]
        return RULES["other"]
    return RULES[best_name]
