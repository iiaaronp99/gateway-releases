"""Use one person's provider keys for that person's calls only.

LiteLLM can take an api_key on the request, but it has stored that key on a
shared deployment (LiteLLM issue 17115). A later caller with no key of their
own could then be served with someone else's free-tier key. That breaks
Google's and OpenRouter's terms, so this router does not do it.

Hosted calls go straight to the provider with the key we just decrypted for
this user. The key is not written on the URL and not included in errors.
Local master-key traffic never reaches this module.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

# Order is the preference for a tier. The first provider this user actually
# has a key for is the one that runs. DeepSeek is the cheap backup on t1.
TIER_PROVIDERS = {
    "fast": (("gemini", "gemini-3.1-flash-lite"),),
    "t1": (
        ("gemini", "gemini-3.1-flash-lite"),
        ("groq", "openai/gpt-oss-120b"),
        ("cloudflare", "@cf/openai/gpt-oss-120b"),
        ("openrouter", "google/gemma-4-31b-it:free"),
        ("deepseek", "deepseek-v4-flash"),
    ),
    "smart": (
        ("gemini", "gemini-3.1-flash-lite"),
        ("groq", "openai/gpt-oss-120b"),
        ("cloudflare", "@cf/openai/gpt-oss-120b"),
        ("openrouter", "google/gemma-4-31b-it:free"),
        ("deepseek", "deepseek-v4-flash"),
    ),
    "t2": (
        ("gemini", "gemini-3.8-flash"),
        ("deepseek", "deepseek-v4-pro"),
    ),
    "t3": (
        ("anthropic", "claude-sonnet-5-5"),
        ("openai", "gpt-6.1-sol"),
    ),
}

PROVIDER_NAMES = {
    "gemini": "Gemini",
    "groq": "Groq",
    "cloudflare": "Cloudflare",
    "openrouter": "OpenRouter",
    "deepseek": "DeepSeek",
    "openai": "OpenAI",
    "anthropic": "Anthropic",
}


@dataclass(frozen=True)
class ProviderKey:
    provider: str
    secret: str
    account_id: str | None = None


@dataclass(frozen=True)
class Target:
    provider: str
    model: str


def select_target(tier: str, keys: dict[str, ProviderKey]) -> Target | None:
    """Pick a provider this user holds. keys must already be only their rows."""
    for provider, model in TIER_PROVIDERS.get(tier, ()):
        owned = keys.get(provider)
        if owned is None or not owned.secret:
            continue
        if provider == "cloudflare" and not owned.account_id:
            continue
        return Target(provider, model)
    return None


def missing_key_message(tier: str) -> str:
    names = [PROVIDER_NAMES[provider] for provider, _model in TIER_PROVIDERS.get(tier, ())]
    if not names:
        return "This tier runs on this computer, not on a provider key."
    listed = ", ".join(names)
    return f"Add your own {listed} key for {tier}. This gateway does not spend a shared key for you."


def endpoint(target: Target, owned: ProviderKey) -> tuple[str, dict[str, str]]:
    secret = owned.secret
    if target.provider == "gemini":
        return "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", {
            "Authorization": f"Bearer {secret}"
        }
    if target.provider == "groq":
        return "https://api.groq.com/openai/v1/chat/completions", {"Authorization": f"Bearer {secret}"}
    if target.provider == "openrouter":
        return "https://openrouter.ai/api/v1/chat/completions", {"Authorization": f"Bearer {secret}"}
    if target.provider == "deepseek":
        return "https://api.deepseek.com/chat/completions", {"Authorization": f"Bearer {secret}"}
    if target.provider == "openai":
        return "https://api.openai.com/v1/chat/completions", {"Authorization": f"Bearer {secret}"}
    if target.provider == "cloudflare":
        account = owned.account_id or ""
        return (
            f"https://api.cloudflare.com/client/v4/accounts/{account}/ai/v1/chat/completions",
            {"Authorization": f"Bearer {secret}"},
        )
    if target.provider == "anthropic":
        return "https://api.anthropic.com/v1/messages", {
            "x-api-key": secret,
            "anthropic-version": "2023-06-01",
        }
    raise ValueError("Unknown provider.")


def public_error(provider: str) -> str:
    name = PROVIDER_NAMES.get(provider, "The provider")
    return f"{name} did not answer. The key was not written in this message."


def chat_body(target: Target, payload: dict) -> dict:
    if target.provider == "anthropic":
        return anthropic_body(target.model, payload)
    body = dict(payload)
    body["model"] = target.model
    body.pop("user", None)
    return body


def anthropic_body(model: str, payload: dict) -> dict:
    system: list[str] = []
    messages = []
    for message in payload.get("messages") or []:
        if not isinstance(message, dict):
            continue
        role = message.get("role")
        content = message.get("content")
        text = content if isinstance(content, str) else json.dumps(content)
        if role == "system":
            system.append(text)
            continue
        if role not in ("user", "assistant"):
            role = "user"
        messages.append({"role": role, "content": text})
    if not messages:
        messages = [{"role": "user", "content": ""}]
    body: dict = {
        "model": model,
        "max_tokens": payload.get("max_tokens") or 1024,
        "messages": messages,
    }
    if system:
        body["system"] = "\n".join(system)
    if payload.get("stream"):
        body["stream"] = True
    return body


def anthropic_to_openai(payload: dict, model: str) -> dict:
    parts = []
    for block in payload.get("content") or []:
        if isinstance(block, dict) and isinstance(block.get("text"), str):
            parts.append(block["text"])
    usage = payload.get("usage") if isinstance(payload.get("usage"), dict) else {}
    prompt = int(usage.get("input_tokens") or 0)
    completion = int(usage.get("output_tokens") or 0)
    return {
        "id": payload.get("id") or "msg",
        "object": "chat.completion",
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "".join(parts)},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": prompt + completion,
        },
    }


async def call_provider(client, target: Target, owned: ProviderKey, payload: dict) -> tuple[int, bytes, str]:
    """Returns status, body, content type. Errors do not include the key or the URL."""
    import httpx

    url, headers = endpoint(target, owned)
    headers = {**headers, "Content-Type": "application/json"}
    outgoing = chat_body(target, payload)
    try:
        response = await client.post(url, headers=headers, content=json.dumps(outgoing).encode("utf-8"))
        raw = await response.aread()
        await response.aclose()
    except httpx.HTTPError:
        message = {"error": {"message": public_error(target.provider), "type": "provider_error"}}
        return 502, json.dumps(message).encode("utf-8"), "application/json"
    if response.status_code >= 400:
        message = {"error": {"message": public_error(target.provider), "type": "provider_error"}}
        return response.status_code, json.dumps(message).encode("utf-8"), "application/json"
    if target.provider == "anthropic":
        if payload.get("stream"):
            converted = anthropic_stream_to_openai(raw, target.model)
            return response.status_code, converted, "text/event-stream"
        try:
            converted = json.dumps(anthropic_to_openai(json.loads(raw), target.model)).encode("utf-8")
        except (json.JSONDecodeError, TypeError, ValueError):
            message = {"error": {"message": public_error("anthropic"), "type": "provider_error"}}
            return 502, json.dumps(message).encode("utf-8"), "application/json"
        return response.status_code, converted, "application/json"
    if payload.get("stream"):
        return response.status_code, raw, "text/event-stream"
    return response.status_code, raw, "application/json"


def anthropic_stream_to_openai(raw: bytes, model: str) -> bytes:
    """Turn Anthropic SSE into the OpenAI chunks the desktop app already reads."""
    chunks: list[bytes] = []
    prompt = completion = 0
    for line in raw.decode("utf-8", errors="replace").splitlines():
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if not data or data == "[DONE]":
            continue
        try:
            event = json.loads(data)
        except json.JSONDecodeError:
            continue
        kind = event.get("type")
        if kind == "content_block_delta":
            delta = event.get("delta") if isinstance(event.get("delta"), dict) else {}
            text = delta.get("text")
            if isinstance(text, str) and text:
                piece = {"choices": [{"index": 0, "delta": {"content": text}}]}
                chunks.append(b"data: " + json.dumps(piece).encode("utf-8") + b"\n\n")
        elif kind == "message_start":
            message = event.get("message") if isinstance(event.get("message"), dict) else {}
            usage = message.get("usage") if isinstance(message.get("usage"), dict) else {}
            prompt = int(usage.get("input_tokens") or prompt)
        elif kind == "message_delta":
            usage = event.get("usage") if isinstance(event.get("usage"), dict) else {}
            completion = int(usage.get("output_tokens") or completion)
    final = {
        "model": model,
        "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        "usage": {
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "total_tokens": prompt + completion,
        },
    }
    chunks.append(b"data: " + json.dumps(final).encode("utf-8") + b"\n\n")
    chunks.append(b"data: [DONE]\n\n")
    return b"".join(chunks)
