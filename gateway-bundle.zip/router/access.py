"""Find the plan for a gateway key. The local master key has no plan.

Redis holds a JSON record written by the account server. The record is keyed
by the SHA-256 of the key, so the key itself is not stored again. Provider
keys are loaded for that user only.
"""

from __future__ import annotations

import hashlib
import json
import os

from byok import ProviderKey
from secret_box import decrypt_string


def bearer_token(authorization: str | None) -> str:
    if not authorization:
        return ""
    parts = authorization.split(" ", 1)
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1].strip()
    return ""


def key_id(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


class Access:
    def __init__(self, redis=None, load_keys=None, master_key: str | None = None):
        self.redis = redis
        self.load_keys = load_keys or (lambda _user_id: {})
        self.master_key = master_key or ""

    @classmethod
    def from_env(cls) -> "Access":
        url = os.environ.get("REDIS_URL", "").strip()
        redis = None
        if url:
            import redis as redis_lib

            redis = redis_lib.Redis.from_url(url, decode_responses=True, socket_timeout=2)
        return cls(
            redis=redis,
            load_keys=postgres_keys_from_env(),
            master_key=os.environ.get("LITELLM_MASTER_KEY", "").strip(),
        )

    def lookup(self, authorization: str | None) -> dict | None:
        """None means the unchanged local path. A dict is a hosted plan or a block."""
        token = bearer_token(authorization)
        if not token:
            return None
        if self.master_key and token == self.master_key:
            return None
        if self.redis is None:
            return None
        try:
            raw = self.redis.get(f"gateway:key:{key_id(token)}")
        except Exception:
            return {"unavailable": True}
        if not raw:
            return {"unregistered": True}
        try:
            plan = json.loads(raw)
        except json.JSONDecodeError:
            return {"unavailable": True}
        if not isinstance(plan, dict) or not plan.get("userId"):
            return {"unavailable": True}
        return plan

    def keys_for(self, user_id: str) -> dict[str, ProviderKey]:
        loaded = self.load_keys(user_id) or {}
        return {name: value for name, value in loaded.items() if isinstance(value, ProviderKey)}


def postgres_keys_from_env():
    database = os.environ.get("DATABASE_URL", "").strip()
    raw_key = os.environ.get("APP_ENCRYPTION_KEY", "").strip()
    if not database or not raw_key:
        return lambda _user_id: {}
    cache: dict[str, tuple[float, dict]] = {}

    def load(user_id: str) -> dict[str, ProviderKey]:
        import time

        hit = cache.get(user_id)
        now = time.time()
        if hit is not None and now - hit[0] < 30:
            return hit[1]
        found = _load_user_keys(database, raw_key, user_id)
        cache[user_id] = (now, found)
        return found

    return load


def _load_user_keys(database: str, raw_key: str, user_id: str) -> dict[str, ProviderKey]:
    import psycopg

    keys: dict[str, ProviderKey] = {}
    with psycopg.connect(database, connect_timeout=3) as conn:
        rows = conn.execute(
            "SELECT provider, ciphertext, account_ciphertext FROM provider_keys WHERE user_id = %s",
            (user_id,),
        ).fetchall()
    for provider, ciphertext, account_ciphertext in rows:
        try:
            secret = decrypt_string(ciphertext, raw_key)
            account = decrypt_string(account_ciphertext, raw_key) if account_ciphertext else None
        except Exception:
            continue
        keys[str(provider)] = ProviderKey(str(provider), secret, account)
    return keys
