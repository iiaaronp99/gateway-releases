"""Tell LiteLLM which replies it may save.

LiteLLM's exact-match cache hashes the request. That hash does not include
the gateway password, so two passwords would otherwise share one saved
answer. This adds a namespace from the password. It also refuses to save
streaming calls and any call whose temperature is not 0.
"""

from __future__ import annotations

from store import key_hash


# Seconds. Matches default_in_memory_ttl in config.yaml.
CACHE_TTL_SECONDS = 3600


def temperature_is_zero(payload: dict) -> bool:
    """True only when the caller set temperature to the number 0."""
    if "temperature" not in payload:
        return False
    value = payload.get("temperature")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return float(value) == 0.0


def cacheable(payload: dict) -> bool:
    """Non-streaming and temperature 0. Anything else must not be stored."""
    if payload.get("stream") is True:
        return False
    return temperature_is_zero(payload)


def apply_cache_policy(payload: dict, authorization: str | None) -> None:
    """Set the LiteLLM `cache` object on this request. Never raises."""
    existing = payload.get("cache")
    cache: dict = dict(existing) if isinstance(existing, dict) else {}
    # The namespace is a short hash, not the password itself.
    namespace = "gw-" + key_hash(authorization)
    client_namespace = cache.get("namespace")
    if isinstance(client_namespace, str) and client_namespace.strip():
        extra = client_namespace.strip()
        if not extra.startswith("gw-"):
            namespace = namespace + ":" + extra[:80]
    cache["namespace"] = namespace
    caller_refuses = cache.get("no-store") is True or cache.get("no-cache") is True
    if caller_refuses or not cacheable(payload):
        cache["no-cache"] = True
        cache["no-store"] = True
        cache.pop("ttl", None)
    else:
        cache.pop("no-cache", None)
        cache.pop("no-store", None)
        cache["ttl"] = CACHE_TTL_SECONDS
    payload["cache"] = cache
