"""Which models `auto` may call.

The file is a reviewed list (catalog/models.json). Missing file means the
router behaves exactly as it did before the catalog existed.

A model is used by `auto` only when it is not retired, the caller has that
provider (a local install: the model is already wired; a hosted account:
they saved that provider key), and it is free or inside their plan. A retired
model is not called. A direct request for a retired or unwired id is refused.
Tier names (auto, t0, t1, t2, fast, smart, local) are left to the existing router.
"""

from __future__ import annotations

import json
from pathlib import Path

TIER_NAMES = {"auto", "t0", "t1", "t2", "t3", "fast", "smart", "local"}
RANK = {"t0": 0, "fast": 1, "t1": 2, "t2": 3, "t3": 4}
# Cheaper only. auto never steps up to a pricier tier because a catalog row said so.
CHEAPER = {
    "t3": ("t2", "t1", "fast", "t0"),
    "t2": ("t1", "fast", "t0"),
    "t1": ("fast", "t0"),
    "fast": ("t0",),
    "t0": (),
}


def load_catalog(path: str | None) -> list[dict] | None:
    """None when there is no file. An empty list is a real catalog with no models."""
    if not path:
        return None
    file = Path(path)
    if not file.is_file():
        return None
    try:
        payload = json.loads(file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    rows = payload.get("models") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return None
    return [row for row in rows if isinstance(row, dict) and isinstance(row.get("id"), str)]


def find_model(catalog: list[dict] | None, model: str) -> dict | None:
    if not catalog:
        return None
    name = model.strip()
    for row in catalog:
        if row.get("id") == name:
            return row
    return None


def block_reason(catalog: list[dict] | None, model: str) -> str | None:
    """Refuse a direct call. Tier names and unknown names are not refused here."""
    if not catalog or model.strip().lower() in TIER_NAMES:
        return None
    row = find_model(catalog, model)
    if row is None:
        return None
    if row.get("deprecated"):
        return "That model is retired. Pick auto, or choose another model on the Models page."
    if not row.get("routable"):
        return "That model is in the catalog, but this gateway is not set up to call it yet."
    return None


def _serves(row: dict, tier: str, owned: set[str] | None, max_tier: str | None) -> bool:
    tiers = row.get("tiers")
    if not isinstance(tiers, list) or tier not in tiers:
        return False
    if row.get("deprecated"):
        return False
    if max_tier and RANK.get(tier, 0) > RANK.get(max_tier, RANK["t2"]):
        return False
    if owned is None:
        has_key = bool(row.get("routable"))
    else:
        has_key = row.get("provider") in owned
    if not has_key:
        return False
    if row.get("free"):
        return True
    if max_tier is None:
        return True
    return RANK.get(tier, 0) <= RANK.get(max_tier, RANK["t2"])


def adjust_auto_model(
    catalog: list[dict] | None,
    chosen: str,
    owned: set[str] | None,
    max_tier: str | None,
    *,
    specific_id: bool,
) -> str:
    """Keep the tier name when the pool is healthy.

    When a wired model in that tier is retired, call one live id instead of the
    whole pool, so the retired deployment is not picked. Hosted calls pass
    specific_id False because they select a provider, not a LiteLLM id.
    """
    if not catalog or chosen not in CHEAPER and chosen != "t0":
        return chosen
    if chosen not in CHEAPER:
        return chosen
    for tier in (chosen, *CHEAPER[chosen]):
        rows = [row for row in catalog if _serves(row, tier, owned, max_tier)]
        if not rows:
            known = [row for row in catalog if isinstance(row.get("tiers"), list) and tier in row["tiers"]]
            if tier == chosen and not known:
                return chosen
            continue
        retired = [
            row
            for row in catalog
            if row.get("deprecated") and row.get("routable") and isinstance(row.get("tiers"), list) and tier in row["tiers"]
        ]
        wired = [row for row in rows if row.get("routable")]
        if specific_id and retired and wired:
            return str(wired[0]["id"])
        return tier
    return chosen
