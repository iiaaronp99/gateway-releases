"""Try a cheaper model first, then one stronger model, for easy auto chats.

Hard chats stay on the tier they already start on. A cascade never runs
twice, and a stream is never switched after the client has been sent a token.
"""

from __future__ import annotations

import json
import logging
import os

from classify import request_text


logger = logging.getLogger("gateway")

# One step up. t2 is the strongest tier this gateway runs.
NEXT_TIER = {"fast": "t1", "t1": "t2"}

# Easy and medium chats. Hard classes are left out on purpose.
EASY_CLASSES = frozenset(
    {
        "quick_chat",
        "summarize",
        "extract",
        "rewrite",
        "translate",
        "classify",
        "data_qa",
    }
)
HARD_CLASSES = frozenset(
    {
        "debug",
        "hard_reasoning",
        "tool_agent",
        "planning",
        "long_context",
    }
)

# A prompt this short may answer with one word. "pong" is in this group.
TRIVIAL_PROMPT_CHARS = 280
# A longer prompt that comes back shorter than this is treated as a failed answer.
MIN_ANSWER_CHARS = 20
# finish_reason "length" only counts when the text itself is still tiny.
TRUNCATED_MAX_CHARS = 40
# How long to wait for the first stream token before trying the next tier.
DEFAULT_STREAM_TIMEOUT = 8.0


def configure_logging() -> None:
    """Show cascade lines in the container log."""
    logger.setLevel(logging.INFO)
    if not any(isinstance(handler, logging.StreamHandler) for handler in logger.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
        logger.addHandler(handler)


def cascade_enabled() -> bool:
    """On unless GATEWAY_CASCADE is 0, false, no, or off."""
    raw = os.environ.get("GATEWAY_CASCADE")
    if raw is None or not raw.strip():
        return True
    return raw.strip().lower() not in {"0", "false", "no", "off"}


def stream_timeout() -> float:
    raw = os.environ.get("GATEWAY_CASCADE_STREAM_TIMEOUT", "")
    if not raw.strip():
        return DEFAULT_STREAM_TIMEOUT
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_STREAM_TIMEOUT
    if value <= 0:
        return DEFAULT_STREAM_TIMEOUT
    return value


def is_simple_code_question(text: str) -> bool:
    """A short coding question, not a request to write a whole program."""
    stripped = text.strip()
    if not stripped or len(stripped) > 500 or "```" in stripped:
        return False
    lowered = stripped.lower()
    if "?" in stripped:
        return True
    return lowered.startswith(("how ", "what ", "why ", "explain ", "can i ", "can you explain"))


def initial_tier(task_class: str, chosen: str, payload: dict) -> str:
    """Simple code questions start on t1. Everything else keeps its pick."""
    if not cascade_enabled():
        return chosen
    if task_class != "coding" or chosen != "t2":
        return chosen
    if is_simple_code_question(request_text(payload)):
        return "t1"
    return chosen


def next_tier(requested: str, task_class: str, tier: str, payload: dict) -> str | None:
    """The one tier we may step up to, or None when this call should not cascade."""
    if not cascade_enabled():
        return None
    if requested.strip().lower() != "auto":
        return None
    if task_class in HARD_CLASSES:
        return None
    nxt = NEXT_TIER.get(tier)
    if nxt is None:
        return None
    if task_class == "coding":
        if is_simple_code_question(request_text(payload)):
            return nxt
        return None
    if task_class not in EASY_CLASSES:
        return None
    return nxt


def note_simple_start(reason: str, old: str, new: str) -> str:
    updated = reason.replace(f"picked={old}", f"picked={new}", 1)
    return _fit(updated, f" simple code question starts on {new}")


def note_cascade(reason: str, old: str, signal: str, new: str) -> str:
    """Append the cascade clause and point picked= at the tier that answered."""
    updated = reason.replace(f"picked={old}", f"picked={new}", 1)
    return _fit(updated, f" cascade: {old} {signal} -> {new}")


def log_cascade(old: str, signal: str, new: str, task_class: str) -> None:
    logger.info("cascade: %s %s -> %s task=%s", old, signal, new, task_class)


def _fit(reason: str, suffix: str) -> str:
    if len(reason) + len(suffix) <= 300:
        return reason + suffix
    keep = max(0, 300 - len(suffix))
    return reason[:keep].rstrip() + suffix


def wants_json(payload: dict) -> bool:
    fmt = payload.get("response_format")
    if isinstance(fmt, dict) and "json" in str(fmt.get("type", "")).lower():
        return True
    if isinstance(fmt, str) and "json" in fmt.lower():
        return True
    return "json" in request_text(payload).lower()


def looks_like_json(text: str) -> bool:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()
    try:
        json.loads(cleaned)
    except json.JSONDecodeError:
        return False
    return True


def _choice_text(choice: dict) -> tuple[str, bool]:
    message = choice.get("message") if isinstance(choice.get("message"), dict) else {}
    if not message and isinstance(choice.get("delta"), dict):
        message = choice["delta"]
    content = message.get("content")
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict) and isinstance(part.get("text"), str):
                parts.append(part["text"])
        content = "".join(parts)
    text = content.strip() if isinstance(content, str) else ""
    tools = bool(message.get("tool_calls") or message.get("function_call"))
    return text, tools


def _anthropic_message(body: dict) -> tuple[str, bool] | None:
    """Text and tool_use from an Anthropic Messages reply, or None if this is not one."""
    if body.get("type") != "message":
        return None
    content = body.get("content")
    if not isinstance(content, list):
        return "", False
    parts: list[str] = []
    tools = False
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "tool_use":
            tools = True
        text = block.get("text")
        if isinstance(text, str):
            parts.append(text)
    return "".join(parts), tools


def failure_signal(payload: dict, status: int, raw: bytes) -> str | None:
    """Why this finished answer is not good enough, or None when it is fine."""
    if status in (408, 504):
        return "timeout"
    if status >= 400 or status <= 0:
        return "error"
    try:
        body = json.loads(raw) if raw else None
    except json.JSONDecodeError:
        return "error"
    if not isinstance(body, dict):
        return "error"
    anthropic = _anthropic_message(body)
    if anthropic is not None:
        text, tools = anthropic
        if tools:
            return None
        if not text:
            return "empty"
        if wants_json(payload) and not looks_like_json(text):
            return "invalid json"
        prompt = request_text(payload).strip()
        if len(prompt) > TRIVIAL_PROMPT_CHARS and len(text) < MIN_ANSWER_CHARS:
            return "short"
        return None
    if body.get("error") and not body.get("choices"):
        return "error"
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        return "empty"
    text, tools = _choice_text(choices[0])
    if tools:
        return None
    finish = choices[0].get("finish_reason")
    if not text:
        return "empty"
    if finish == "length" and len(text) <= TRUNCATED_MAX_CHARS:
        return "truncated"
    if wants_json(payload) and not looks_like_json(text):
        return "invalid json"
    prompt = request_text(payload).strip()
    if len(prompt) > TRIVIAL_PROMPT_CHARS and len(text) < MIN_ANSWER_CHARS:
        return "short"
    return None


def payload_has_text(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    if payload.get("type") == "content_block_delta":
        delta = payload.get("delta")
        if isinstance(delta, dict) and isinstance(delta.get("text"), str) and delta["text"]:
            return True
    choices = payload.get("choices")
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        text, _tools = _choice_text(choices[0])
        return bool(text)
    return False


def stream_has_text(raw: bytes) -> bool:
    """True once a stream chunk carries answer text. Unknown chunks count too."""
    for line in raw.decode("utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if not data or data == "[DONE]":
            continue
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            return True
        if payload_has_text(payload):
            return True
    return False


def stream_has_error(raw: bytes) -> bool:
    for line in raw.decode("utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if not data or data == "[DONE]":
            continue
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict) and payload.get("error") and not payload_has_text(payload):
            return True
    return False
