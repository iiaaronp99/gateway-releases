"""Plan ceiling for `auto`. Classification and learning are not changed here.

A missing plan means the local single-user gateway: the tier is left alone.
Free stops at t2. Basic and above may use t3 when the rule and the pick were
already t2, which is the top tier the classifier knows about. That step uses
the caller's own provider key.
"""

from __future__ import annotations

import os

RANK = {"t0": 0, "fast": 1, "t1": 2, "t2": 3, "t3": 4}
ALIASES = {"smart": "t1", "local": "t0"}


def cap_auto_tier(chosen: str, rule_tier: str, max_tier: str | None) -> str:
    if not max_tier:
        return chosen
    tier = chosen
    if max_tier == "t3" and rule_tier == "t2" and chosen == "t2":
        tier = "t3"
    ceiling = RANK.get(max_tier, RANK["t2"])
    if RANK.get(tier, 0) > ceiling:
        return max_tier
    return tier


def tier_allowed(model: str, max_tier: str | None) -> bool:
    """Named models at or under the plan ceiling. `auto` is capped later."""
    if not max_tier:
        return True
    name = ALIASES.get(model.strip().lower(), model.strip().lower())
    if name == "auto" or name not in RANK:
        return True
    return RANK[name] <= RANK.get(max_tier, RANK["t2"])


def platform_key_allowed(plan: dict | None, env: dict | None = None) -> bool:
    """True only when hosted credits are switched on and this plan has a budget.

    The budget in the plan file is $0 for every plan, so this stays false
    until someone raises a budget on purpose. A false result must not call a
    platform provider key.
    """
    if not plan:
        return False
    source = env if env is not None else os.environ
    if str(source.get("HOSTED_CREDITS_ENABLED", "0")).strip() != "1":
        return False
    try:
        budget = float(plan.get("hostedCreditBudgetUsd") or 0)
    except (TypeError, ValueError):
        return False
    return budget > 0


def note_plan_tier(reason: str, old: str, new: str, max_tier: str) -> str:
    updated = reason.replace(f"picked={old}", f"picked={new}", 1)
    text = f"{updated} plan cap={max_tier}"
    return " ".join(text.split())[:300]
