"""Pick a tier for `auto` from the rule plus this user's marks.

Each user, task class, and tier has two counts, like a coin that can land
good or bad. A new pair starts at one good and one bad, so every tier is
possible. The rule adds pretend marks: a sure rule adds more, a shaky rule
adds fewer. A real "good" or "bad" from gw changes the real counts.

The pick is one random draw from each tier's counts (Thompson sampling).
The tier with the highest draw is used. A sure rule usually wins. A run of
bad marks on that tier, and good marks on another, can change the pick.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from classify import Rule


TIERS = ("fast", "t0", "t1", "t2")

# How many pretend marks a confidence of 1.0 is worth.
# 4 means a very sure rule starts ahead, and several real bad marks can pass it.
RULE_PRIOR = 4.0

# smart and local are names for tiers. Feedback on those names teaches the tier.
TIER_ALIASES = {"smart": "t1", "local": "t0"}


@dataclass(frozen=True)
class Choice:
    tier: str
    learned: bool


def learning_tier(model_name: str) -> str | None:
    """The tier a mark should teach, or None when this name is not one of ours."""
    name = TIER_ALIASES.get(model_name, model_name)
    if name in TIERS:
        return name
    return None


def choose(
    rule: Rule,
    counts: dict[str, tuple[float, float]],
    rng: random.Random | None = None,
) -> Choice:
    """counts maps a tier to (good weight, bad weight), already including the 1, 1 start."""
    draw = rng or random.Random()
    bonus = max(0.0, min(1.0, rule.confidence)) * RULE_PRIOR
    best_tier = rule.tier
    best_sample = -1.0
    for tier in TIERS:
        good, bad = counts.get(tier, (1.0, 1.0))
        if tier == rule.tier:
            good += bonus
        else:
            bad += bonus
        sample = draw.betavariate(good, bad)
        if sample > best_sample:
            best_sample = sample
            best_tier = tier
    return Choice(tier=best_tier, learned=best_tier != rule.tier)


def route_reason(rule: Rule, requested: str, choice: Choice | None) -> str:
    """One line, safe to put in a response header. No user text."""
    if requested.strip().lower() != "auto":
        shown = requested.strip() or "(none)"
        text = (
            f"task={rule.task_class}; picked={shown}; learning=not used; "
            f"you asked for {shown}, so the router left it alone"
        )
    else:
        assert choice is not None
        changed = "changed the pick" if choice.learned else "agreed"
        text = (
            f"task={rule.task_class}; rule={rule.tier} ({rule.confidence:.2f}); "
            f"picked={choice.tier}; learning={changed}; {rule.reason}"
        )
    return " ".join(text.split())[:300]
