"""Call OpenRouter with a key this gateway was given.

The key is not written into LiteLLM. LiteLLM has kept a caller's key on a
shared deployment before, so a later caller could have used it. This module
talks to OpenRouter itself and does not log the key or the prompt.
"""

from __future__ import annotations

import json
import os

FREE_MODEL_NOTICE = (
    "Free-model providers may use what you type to train their models. "
    "Do not send private or sensitive text on a free model."
)

TIER_NAMES = {"", "auto", "smart", "t1", "t2", "t3", "fast"}
LOCAL_NAMES = {"t0", "local"}


def local_mode() -> bool:
    return os.environ.get("GATEWAY_LOCAL", "").strip().lower() in {"1", "true", "yes", "on"}


def privacy_routing() -> bool:
    raw = os.environ.get("GATEWAY_PRIVACY", "1").strip().lower()
    return raw not in {"0", "false", "off", "no"}


def is_free_model(model: str) -> bool:
    return ":free" in model.lower()


def ollama_chat_url() -> str:
    base = os.environ.get("OLLAMA_API_BASE", "http://127.0.0.1:11434/v1").rstrip("/")
    return base + "/chat/completions"


def ollama_model(requested: str) -> str:
    name = requested.strip()
    if name.lower() in {"", "auto", "t0", "local"}:
        return os.environ.get("OLLAMA_MODEL", "llama3.2")
    return name


def openrouter_chat_url() -> str:
    base = os.environ.get("OPENROUTER_API_BASE", "https://openrouter.ai/api/v1").rstrip("/")
    return base + "/chat/completions"


def openrouter_model(requested: str) -> str:
    """Gateway names such as auto become OpenRouter's own auto router."""
    name = requested.strip()
    lower = name.lower()
    if lower in TIER_NAMES:
        return "openrouter/auto"
    if lower.startswith("openrouter/"):
        return name
    return name


def should_call_openrouter(requested: str, has_key: bool) -> bool:
    if not has_key:
        return False
    lower = requested.strip().lower()
    if lower in LOCAL_NAMES:
        return False
    if lower in TIER_NAMES:
        return True
    if "/" in requested or lower.startswith("openrouter"):
        return True
    return False


def apply_privacy(payload: dict, *, explicit_free: bool) -> dict:
    """Ask OpenRouter to skip providers that train on prompts.

    An explicit :free model is left as the caller asked, after they accepted
    the notice. Those models often only exist on providers that collect prompts.
    """
    body = dict(payload)
    body.pop("user", None)
    if explicit_free or not privacy_routing():
        return body
    provider = body.get("provider")
    if not isinstance(provider, dict):
        provider = {}
    else:
        provider = dict(provider)
    provider.setdefault("data_collection", "deny")
    body["provider"] = provider
    return body


def free_model_blocked(model: str, accept_free: bool) -> bool:
    return is_free_model(model) and not accept_free


def accepts_free(header: str | None) -> bool:
    if header is None:
        return False
    return header.strip().lower() in {"1", "true", "yes", "on"}


async def call_ollama(client, payload: dict):
    """Talk to Ollama on this computer. There is no key."""
    requested = payload.get("model") if isinstance(payload.get("model"), str) else "t0"
    body = dict(payload)
    body["model"] = ollama_model(str(requested))
    body.pop("user", None)
    body.pop("provider", None)
    request = client.build_request(
        "POST",
        ollama_chat_url(),
        headers={"Content-Type": "application/json"},
        content=json.dumps(body).encode("utf-8"),
    )
    return await client.send(request, stream=True)


async def call_openrouter(client, key: str, payload: dict):
    """Stream the provider response. The key stays in the Authorization header only."""
    requested = payload.get("model") if isinstance(payload.get("model"), str) else "auto"
    explicit_free = is_free_model(str(requested))
    body = apply_privacy(payload, explicit_free=explicit_free)
    body["model"] = openrouter_model(str(requested))
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://127.0.0.1:4000",
        "X-Title": "Ape1ron Gateway",
    }
    outgoing = json.dumps(body).encode("utf-8")
    request = client.build_request("POST", openrouter_chat_url(), headers=headers, content=outgoing)
    return await client.send(request, stream=True)
