"""The local front door on port 4000.

LiteLLM stays behind this process and keeps the model pool, the timeouts,
and the fallbacks. This process adds `auto`, good/bad marks, and (on the
cost page) a place to look at what calls cost.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

from cascade import configure_logging
from classify import TASK_TYPES, class_to_type
from catalog import load_catalog
from dashboard import render
from direct_provider import FREE_MODEL_NOTICE, local_mode
from local_guard import registration_block
from proxy import Gateway
from shortlist import load_shortlist
from store import Store, learning_body_error, user_id

APP_NAME_LIMIT = 40
PROVIDER_IDS = {
    "openrouter",
    "gemini",
    "groq",
    "openai",
    "anthropic",
    "deepseek",
    "mistral",
    "cloudflare",
}


configure_logging()


def create_app(
    upstream: str | None = None,
    data_dir: str | None = None,
    rng=None,
    catalog_path: str | None = None,
    shortlist_path: str | None = None,
) -> FastAPI:
    target = upstream or os.environ.get("GATEWAY_UPSTREAM", "http://127.0.0.1:4001")
    folder = data_dir or os.environ.get("GATEWAY_DATA_DIR", "data")
    store = Store(os.path.join(folder, "gateway.sqlite"))
    path = os.environ.get("CATALOG_PATH") if catalog_path is None else catalog_path
    listed = os.environ.get("SHORTLIST_PATH") if shortlist_path is None else shortlist_path
    gateway = Gateway(
        target,
        store,
        rng=rng,
        catalog=load_catalog(path),
        shortlist=load_shortlist(listed),
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await gateway.startup()
        yield
        await gateway.shutdown()
        store.close()

    app = FastAPI(title="AI Gateway", lifespan=lifespan)
    app.state.gateway = gateway
    app.state.store = store

    if local_mode():

        @app.get("/health/liveliness")
        async def live():
            return {"status": "ok"}

    @app.get("/dashboard", response_class=HTMLResponse)
    @app.get("/weekly", response_class=HTMLResponse)
    async def dashboard():
        return HTMLResponse(render(store.report()))

    @app.get("/api/weekly")
    async def weekly_json():
        return store.report()

    @app.get("/api/catalog")
    async def catalog_json():
        return {"version": 1, "available": gateway.catalog is not None, "models": gateway.catalog or []}

    @app.post("/api/provider-test")
    async def provider_test(request: Request):
        return await gateway.provider_test(request)

    @app.post("/feedback")
    @app.post("/v1/feedback")
    async def feedback(request: Request):
        authorization = request.headers.get("authorization")
        if authorization is None or not authorization.lower().startswith("bearer "):
            return JSONResponse(
                {"error": "Send the gateway password as Authorization: Bearer sk-..."},
                status_code=401,
            )
        if not authorization.split(" ", 1)[1].strip():
            return JSONResponse({"error": "The gateway password is empty."}, status_code=401)
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"error": "Send JSON like {\"rating\": \"good\"}."}, status_code=400)
        if not isinstance(payload, dict):
            return JSONResponse({"error": "Send a JSON object with rating set to good or bad."}, status_code=400)
        rating = str(payload.get("rating", "")).strip().lower()
        if rating not in ("good", "bad"):
            return JSONResponse({"error": "rating must be good or bad."}, status_code=400)
        request_id = payload.get("request_id") or payload.get("id")
        if request_id is not None and not isinstance(request_id, str):
            return JSONResponse({"error": "request_id must be the id from x-gateway-request-id."}, status_code=400)
        if request_id:
            row = store.get_request(request_id)
        else:
            row = store.latest_for_key(authorization)
        if row is None:
            return JSONResponse(
                {"error": "No call to mark yet. Send a chat first, then run gw good or gw bad."},
                status_code=404,
            )
        if not store.same_key(row["user_id"], authorization):
            return JSONResponse({"error": "That call belongs to a different key."}, status_code=403)
        store.rate(row, rating)
        return {
            "ok": True,
            "request_id": row["id"],
            "rating": rating,
            "task": row["task_class"],
            "tier": row["chosen_tier"],
        }

    def _authorized(request: Request):
        authorization = request.headers.get("authorization")
        if authorization is None or not authorization.lower().startswith("bearer "):
            return None, JSONResponse(
                {"error": "Send the gateway password as Authorization: Bearer sk-..."},
                status_code=401,
            )
        if not authorization.split(" ", 1)[1].strip():
            return None, JSONResponse({"error": "The gateway password is empty."}, status_code=401)
        return authorization, None

    @app.post("/api/learning/signal")
    async def learning_signal(request: Request):
        authorization, rejected = _authorized(request)
        if rejected is not None:
            return rejected
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"error": "Send JSON like {\"kind\": \"copy\"}."}, status_code=400)
        if not isinstance(payload, dict):
            return JSONResponse({"error": "Send a JSON object."}, status_code=400)
        blocked = learning_body_error(payload)
        if blocked:
            return JSONResponse({"error": blocked}, status_code=400)
        kind = str(payload.get("kind", "")).strip().lower()
        if kind not in {"copy", "regenerate", "cancel", "switch", "good", "bad"}:
            return JSONResponse(
                {"error": "kind must be copy, regenerate, cancel, switch, good, or bad."},
                status_code=400,
            )
        request_id = payload.get("request_id") or payload.get("id")
        task = payload.get("task_type") if isinstance(payload.get("task_type"), str) else None
        model = payload.get("model") if isinstance(payload.get("model"), str) else None
        owner = user_id(authorization, None)
        if isinstance(request_id, str) and request_id:
            row = store.get_request(request_id)
            if row is None or not store.same_key(row["user_id"], authorization):
                return JSONResponse({"error": "That call belongs to a different key."}, status_code=403)
            owner = row["user_id"]
            if not task:
                task = row["task_type"] or class_to_type(row["task_class"])
            if not model:
                model = row["served_model"] or ""
        if task not in TASK_TYPES:
            task = class_to_type(task)
        store.record_signal(owner, kind, task_type=task, model=model)
        return {"ok": True, "kind": kind}

    @app.post("/api/learning/delete")
    async def learning_delete(request: Request):
        authorization, rejected = _authorized(request)
        if rejected is not None:
            return rejected
        cleared = store.delete_learning(authorization)
        return {"ok": True, **cleared}

    def _local_only(request: Request):
        blocked = registration_block(
            request.client.host if request.client is not None else None,
            request.headers.get("host"),
            request.headers.get("origin"),
            request.headers.get("x-forwarded-for"),
        )
        if blocked:
            return JSONResponse({"error": blocked}, status_code=403)
        return None

    def _master_token(request: Request) -> str:
        authorization = request.headers.get("authorization") or ""
        parts = authorization.split(" ", 1)
        if len(parts) != 2 or parts[0].lower() != "bearer":
            return ""
        return parts[1].strip()

    @app.post("/v1/apps/register")
    async def register_app(request: Request):
        """Give a local app its own key. Remote callers are refused."""
        refused = _local_only(request)
        if refused is not None:
            return refused
        content_type = (request.headers.get("content-type") or "").split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            return JSONResponse({"error": "Send JSON like {\"app\": \"Odyssey\"}."}, status_code=415)
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"error": "Send JSON like {\"app\": \"Odyssey\"}."}, status_code=400)
        if not isinstance(payload, dict):
            return JSONResponse({"error": "Send a JSON object with app set to the app name."}, status_code=400)
        raw_name = payload.get("app")
        if not isinstance(raw_name, str):
            return JSONResponse({"error": "Send {\"app\": \"the app name\"}."}, status_code=400)
        name = " ".join(raw_name.split())
        if not name or len(name) > APP_NAME_LIMIT:
            return JSONResponse({"error": "The app name needs 1 to 40 characters."}, status_code=400)
        if any(ord(char) < 32 or char in "\\/\0" for char in name):
            return JSONResponse({"error": "The app name has a character that is not allowed."}, status_code=400)
        try:
            created = store.register_app(name)
        except ValueError as error:
            return JSONResponse({"error": str(error)}, status_code=429)
        return {
            "app": created["app"],
            "key": created["key"],
            "base_url": "http://127.0.0.1:4000/v1",
            "model": "auto",
        }

    @app.get("/v1/apps")
    async def list_apps(request: Request):
        """Names, counts, and a working light. No prompts and no keys."""
        refused = _local_only(request)
        if refused is not None:
            return refused
        master = gateway.access.master_key
        if not master or _master_token(request) != master:
            return JSONResponse(
                {"error": "Send the gateway password as Authorization: Bearer sk-..."},
                status_code=401,
            )
        return {"apps": store.list_apps()}

    @app.post("/v1/provider-keys")
    async def save_provider_key(request: Request):
        """Keep a provider key for this gateway. It is not written in the reply."""
        refused = _local_only(request)
        if refused is not None:
            return refused
        master = gateway.access.master_key
        if not master or _master_token(request) != master:
            return JSONResponse(
                {"error": "Send the gateway password as Authorization: Bearer sk-..."},
                status_code=401,
            )
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"error": "Send JSON with provider and key."}, status_code=400)
        if not isinstance(payload, dict):
            return JSONResponse({"error": "Send a JSON object."}, status_code=400)
        provider = payload.get("provider")
        secret = payload.get("key")
        if not isinstance(provider, str) or provider.strip().lower() not in PROVIDER_IDS:
            return JSONResponse({"error": "Name a known provider."}, status_code=400)
        if not isinstance(secret, str) or not secret.strip() or any(char in secret for char in "\r\n\0"):
            return JSONResponse({"error": "The provider key is empty."}, status_code=400)
        gateway.remember_provider_key(provider.strip().lower(), secret.strip())
        return {"ok": True, "provider": provider.strip().lower(), "notice": FREE_MODEL_NOTICE}

    @app.api_route(
        "/{path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    )
    async def forward(path: str, request: Request):
        return await gateway.forward(request)

    return app


app = create_app()
