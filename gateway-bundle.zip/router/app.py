"""The local front door on port 4000.

LiteLLM stays behind this process and keeps the model pool, the timeouts,
and the fallbacks. This process adds `auto`, good/bad marks, and (on the
cost page) a place to look at what calls cost.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

from cascade import configure_logging
from catalog import load_catalog
from dashboard import render
from proxy import Gateway
from store import Store


configure_logging()


def create_app(upstream: str | None = None, data_dir: str | None = None, rng=None, catalog_path: str | None = None) -> FastAPI:
    target = upstream or os.environ.get("GATEWAY_UPSTREAM", "http://127.0.0.1:4001")
    folder = data_dir or os.environ.get("GATEWAY_DATA_DIR", "data")
    store = Store(os.path.join(folder, "gateway.sqlite"))
    path = os.environ.get("CATALOG_PATH") if catalog_path is None else catalog_path
    gateway = Gateway(target, store, rng=rng, catalog=load_catalog(path))

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await gateway.startup()
        yield
        await gateway.shutdown()
        store.close()

    app = FastAPI(title="AI Gateway", lifespan=lifespan)
    app.state.gateway = gateway
    app.state.store = store

    @app.get("/dashboard", response_class=HTMLResponse)
    @app.get("/weekly", response_class=HTMLResponse)
    async def dashboard():
        return HTMLResponse(render(store.report()))

    @app.get("/api/weekly")
    async def weekly_json():
        return store.report()

    @app.get("/api/catalog")
    async def catalog_json():
        return {"version": 1, "available": gateway.catalog is not None, "models": gateway.catalog or []}

    @app.post("/api/provider-test")
    async def provider_test(request: Request):
        return await gateway.provider_test(request)

    @app.post("/feedback")
    @app.post("/v1/feedback")
    async def feedback(request: Request):
        authorization = request.headers.get("authorization")
        if authorization is None or not authorization.lower().startswith("bearer "):
            return JSONResponse(
                {"error": "Send the gateway password as Authorization: Bearer sk-..."},
                status_code=401,
            )
        if not authorization.split(" ", 1)[1].strip():
            return JSONResponse({"error": "The gateway password is empty."}, status_code=401)
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse({"error": "Send JSON like {\"rating\": \"good\"}."}, status_code=400)
        if not isinstance(payload, dict):
            return JSONResponse({"error": "Send a JSON object with rating set to good or bad."}, status_code=400)
        rating = str(payload.get("rating", "")).strip().lower()
        if rating not in ("good", "bad"):
            return JSONResponse({"error": "rating must be good or bad."}, status_code=400)
        request_id = payload.get("request_id") or payload.get("id")
        if request_id is not None and not isinstance(request_id, str):
            return JSONResponse({"error": "request_id must be the id from x-gateway-request-id."}, status_code=400)
        if request_id:
            row = store.get_request(request_id)
        else:
            row = store.latest_for_key(authorization)
        if row is None:
            return JSONResponse(
                {"error": "No call to mark yet. Send a chat first, then run gw good or gw bad."},
                status_code=404,
            )
        if not store.same_key(row["user_id"], authorization):
            return JSONResponse({"error": "That call belongs to a different key."}, status_code=403)
        store.rate(row, rating)
        return {
            "ok": True,
            "request_id": row["id"],
            "rating": rating,
            "task": row["task_class"],
            "tier": row["chosen_tier"],
        }

    @app.api_route(
        "/{path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    )
    async def forward(path: str, request: Request):
        return await gateway.forward(request)

    return app


app = create_app()
