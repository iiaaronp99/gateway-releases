"""Which shortlist models `auto` may send for this user.

The file is catalog/shortlist.json. It is produced by the weekly job and
does nothing until that pull request is merged. A missing file leaves `auto`
on the tier it already picked.
"""

from __future__ import annotations

import json
from pathlib import Path

from catalog import RANK

TASK_USE_CASE = {
    "fast_chat": "chat",
    "coding": "coding",
    "reasoning": "reasoning",
    "long_doc": "long_docs",
    "vision": "vision",
}

POOL_TIERS = {"t0", "t1", "t2", "t3", "fast"}


def load_shortlist(path: str | None) -> dict | None:
    if not path:
        return None
    file = Path(path)
    if not file.is_file():
        return None
    try:
        payload = json.loads(file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict) or not isinstance(payload.get("use_cases"), dict):
        return None
    return payload


def _allowed(row: dict, tier: str, owned: set[str] | None, max_tier: str | None) -> bool:
    if row.get("deprecated"):
        return False
    if max_tier and RANK.get(tier, 0) > RANK.get(max_tier, RANK["t3"]):
        return False
    if owned is None:
        if not row.get("routable"):
            return False
    elif row.get("provider") not in owned:
        return False
    if row.get("free"):
        return True
    if max_tier is None:
        return True
    return RANK.get(tier, 0) <= RANK.get(max_tier, RANK["t3"])


def _auto_picks(shortlist: dict, task_type: str, tier: str) -> list[dict]:
    use_cases = shortlist.get("use_cases") or {}
    names = [TASK_USE_CASE.get(task_type, "chat")]
    if task_type == "fast_chat":
        names.append("fast_cheap")
    if tier == "t0":
        names.append("private_local")
    picks: list[dict] = []
    for name in names:
        block = use_cases.get(name) or {}
        rows = (block.get("tiers") or {}).get("auto") or []
        if isinstance(rows, list):
            picks.extend(row for row in rows if isinstance(row, dict))
    return picks


def candidate_ids(
    shortlist: dict | None,
    task_type: str,
    tier: str,
    catalog: list[dict] | None,
    owned: set[str] | None,
    max_tier: str | None,
) -> list[str]:
    """Routable shortlist models for this task and tier, best score first."""
    if not shortlist or tier not in POOL_TIERS:
        return []
    by_id = {row["id"]: row for row in catalog or [] if isinstance(row.get("id"), str)}
    ordered: list[str] = []
    seen: set[str] = set()
    for pick in _auto_picks(shortlist, task_type, tier):
        model_id = pick.get("id")
        if not isinstance(model_id, str) or model_id in seen:
            continue
        row = by_id.get(model_id)
        if row is None:
            continue
        listed = row.get("tiers") if isinstance(row.get("tiers"), list) else []
        if tier not in listed and pick.get("tier") != tier:
            continue
        if not _allowed(row, tier, owned, max_tier):
            continue
        seen.add(model_id)
        ordered.append(model_id)
    return ordered
