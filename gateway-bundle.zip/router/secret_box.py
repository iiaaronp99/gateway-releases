"""AES-256-GCM, same layout as the account server.

Stored value is base64(iv || ciphertext || tag). The tag is the last 16 bytes.
Plaintext is never logged. This file is not named secrets.py, because that
would hide Python's own secrets module.
"""

from __future__ import annotations

import base64
import os


def encryption_key(raw: str | None = None) -> bytes:
    text = (raw if raw is not None else os.environ.get("APP_ENCRYPTION_KEY", "")).strip()
    if not text:
        raise ValueError("APP_ENCRYPTION_KEY is not set.")
    if len(text) == 64 and all(char in "0123456789abcdefABCDEF" for char in text):
        return bytes.fromhex(text)
    encoded = text.encode("utf-8")
    if len(encoded) == 32:
        return encoded
    try:
        decoded = base64.b64decode(text, validate=True)
    except Exception as error:
        raise ValueError("APP_ENCRYPTION_KEY must be 32 bytes, 64 hex characters, or base64 of 32 bytes.") from error
    if len(decoded) != 32:
        raise ValueError("APP_ENCRYPTION_KEY must be 32 bytes, 64 hex characters, or base64 of 32 bytes.")
    return decoded


def decrypt_string(encoded: str, raw_key: str | None = None) -> str:
    packed = base64.b64decode(encoded)
    if len(packed) < 12 + 16:
        raise ValueError("The stored secret is damaged.")
    iv, tag = packed[:12], packed[-16:]
    ciphertext = packed[12:-16]
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    plain = AESGCM(encryption_key(raw_key)).decrypt(iv, ciphertext + tag, None)
    return plain.decode("utf-8")
