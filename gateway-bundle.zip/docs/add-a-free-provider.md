Friend bundle note: this folder is the gateway folder.
When a step says gateway/.env or gateway/config.yaml, use the .env and config.yaml next to docker-compose.yml.

# Add a free provider

This adds another company to the free cloud pool (`t1` / `smart`). You sign up with your own account. The key stays in `gateway/.env` on your computer. It is not committed, and it is not shared with anyone else.

The gateway does not start these providers until you turn them on. The lines are already written. A `#` at the start of a line means "ignore this".

## Which ones to try

Checked against LiteLLM v1.109.1 (the image this gateway runs) and each company's docs on 2026-11-17. Nothing here was called with a real key.

| Company | LiteLLM model id | OpenAI-compatible? | What to know before you paste a key |
| --- | --- | --- | --- |
| Groq | `groq/openai/gpt-oss-120b` | Yes. LiteLLM's `groq/` provider speaks Groq's OpenAI-style API. Groq's own id is `openai/gpt-oss-120b`. | Groq has a free plan. Confirm `openai/gpt-oss-120b` is still on that plan when you sign up. Limits change. |
| Cloudflare Workers AI | `cloudflare/@cf/openai/gpt-oss-120b` | Yes for chat. LiteLLM uses Workers AI's OpenAI-style `/ai/v1/chat/completions`. | Free tier is 10,000 neurons a day. After that, the paid Workers plan charges money. You need two values: an API token and your account id. |
| Inception | `inception/mercury-2` | Yes. Base URL `https://api.inceptionlabs.ai/v1`. | The model has a list price in LiteLLM (not zero). Inception has said a new key includes free tokens. That is a starter grant, not a forever-free model. Stop when the grant runs out. |
| Scaleway | `scaleway/openai/gpt-oss-120b` | Yes. LiteLLM lists it as an OpenAI-compatible provider. Base URL `https://api.scaleway.ai/v1`. Env name is `SCW_SECRET_KEY`. | LiteLLM v1.109.1's price list uses this id. Scaleway's own page also lists the model as `gpt-oss-120b`. Not checked with a live call. The list price is not zero. Turn it on only if your Scaleway account still shows free credit. If the call says the model does not exist, change the model line to `scaleway/gpt-oss-120b` and restart. |
| Cerebras | `cerebras/gpt-oss-120b` | Yes. LiteLLM's `cerebras/` provider is OpenAI-compatible. The id on the wire is `gpt-oss-120b`, not `openai/gpt-oss-120b`. | The list price is not zero. A trial credit often asks for a payment method. Do not add a card if you want to stay at $0. |
| Aion | `openai/aion-labs/aion-3.5` with `api_base: https://api.aionlabs.ai/v1` | Yes. Their docs say the API matches the OpenAI client. | Aion is not a built-in LiteLLM provider, so the model line uses the `openai/` prefix plus their base URL. Their public model list on 2026-11-17 shows a price for every model, including `aion-labs/aion-3.5` (about $3 per million input tokens). Not a free model on that list. Leave it commented unless your dashboard says the key will not be charged. Not checked with a live call. |

Sign-up pages:

- Groq: <https://console.groq.com/keys>
- Cloudflare: <https://dash.cloudflare.com> then Workers AI. Create an API token, and copy the account id from the dashboard URL (the long hex string).
- Inception: <https://www.inceptionlabs.ai> then their platform, and create an API key. The exact click path was not re-checked.
- Scaleway: <https://console.scaleway.com> then Generative APIs, and create a secret key.
- Cerebras: <https://cloud.cerebras.ai>
- Aion: the docs are at <https://api.aionlabs.ai/docs/api-reference/>. Keys are created in their dashboard. The exact click path was not re-checked.

## Steps

Do this from the `gateway` folder. Docker Desktop must be open.

1. Create the account on that site. Use your own email. Do not use someone else's key.
2. Create a key and copy it. Close the page after you copy it. You often cannot see the key again.
3. Open `gateway/.env` in Notepad.
4. Find that company's line. Delete the `#` and the space after it. Paste the key after the `=`.
   - No quotes.
   - No spaces around the `=`.
   - Cloudflare also has `CLOUDFLARE_ACCOUNT_ID`. Uncomment that line and paste the account id. It is not a secret in the same way, but it still stays in `.env`.
5. Save `.env`.
6. Open `gateway/config.yaml`.
7. Find that company's block. It is under `t1`, near the bottom of the free-model list. Every line of the block starts with `#`.
8. On each line of that block only, delete `#` and the one space after it. Leave the rest of the line where it is. The `- model_name` line should line up with the other `- model_name` lines above it.
9. Save `config.yaml`.
10. Restart, then wait about a minute:

```powershell
cd ~\ai-gateway
cd gateway
docker compose up -d --force-recreate
```

11. Test:

```powershell
powershell -ExecutionPolicy Bypass -File .\test.ps1
```

A good `t1` or `smart` reply contains the word `pong`. `Answered by` may show the new model. The pool still prefers whichever model has been fastest lately, so you may not see the new name on the first call.

## Example: turning Groq on

`.env` before:

```text
# GROQ_API_KEY=
```

`.env` after:

```text
GROQ_API_KEY=gsk_paste_your_own_key_here
```

`config.yaml` before (shorter than the real block):

```yaml
  # - model_name: t1
  #   litellm_params:
  #     model: "groq/openai/gpt-oss-120b"
  #     api_key: "os.environ/GROQ_API_KEY"
```

`config.yaml` after:

```yaml
  - model_name: t1
    litellm_params:
      model: "groq/openai/gpt-oss-120b"
      api_key: "os.environ/GROQ_API_KEY"
```

The spaces before `model_name` and `litellm_params` matter. If the gateway says the config file failed to load, the indentation is wrong. Put the `#` lines back, or restore the file with git and start this section again.

## Turn one back off

1. Put `# ` back at the start of that block in `config.yaml`.
2. Put `# ` back at the start of that key in `.env`.
3. Run `docker compose up -d --force-recreate` from the `gateway` folder.

The other models keep working. `t0`, `t1`, `t2`, `smart`, `local`, `fast`, and `auto` do not change names.
