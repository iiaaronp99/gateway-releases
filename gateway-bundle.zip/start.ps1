# Start the local gateway on Windows. From this folder:
#   powershell -ExecutionPolicy Bypass -File .\start.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "Docker is not installed, or it is not on your PATH."
    Write-Host "Install Docker Desktop, open it, wait until it says it is running, then try again."
    exit 1
}

docker info *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Docker is installed, but the engine is not running."
    Write-Host "Open Docker Desktop and wait until it says it is running, then try again."
    exit 1
}

if (-not (Test-Path .env)) {
    Write-Host "Missing .env in this folder."
    Write-Host "Copy the example, then paste your keys:"
    Write-Host "  Copy-Item .env.example .env"
    exit 1
}

$envText = Get-Content -Raw .env
if ($envText -match "paste-your-" -or $envText -match "sk-replace-me") {
    Write-Host "Your .env still has placeholder text (paste-your-... or sk-replace-me)."
    Write-Host "Open .env, paste your Gemini and OpenRouter keys, and set LITELLM_MASTER_KEY."
    exit 1
}

Write-Host "Starting the gateway on http://localhost:4000"
Write-Host "The first start downloads LiteLLM and builds the small router. That can take a few minutes."
Write-Host "Leave this window open. Press Ctrl+C to stop."
Write-Host "To run in the background instead, use: docker compose up -d --build"
docker compose up
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
